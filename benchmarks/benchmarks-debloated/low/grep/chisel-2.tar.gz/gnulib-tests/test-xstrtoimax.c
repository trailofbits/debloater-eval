#define __xstrtol xstrtoimax
#define __strtol_t intmax_t
#define __spec PRIdMAX
#include "test-xstrtol.c"
