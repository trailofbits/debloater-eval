#define LENGTH 3
#include "ftoastr.c"
