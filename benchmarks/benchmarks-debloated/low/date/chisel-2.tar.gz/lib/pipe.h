/* Obsolete; consider using spawn-pipe.h instead.  */
#include "spawn-pipe.h"
