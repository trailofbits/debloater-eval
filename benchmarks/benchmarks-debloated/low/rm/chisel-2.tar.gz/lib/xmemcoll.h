#include <stddef.h>
int xmemcoll (char *, size_t, char *, size_t);
