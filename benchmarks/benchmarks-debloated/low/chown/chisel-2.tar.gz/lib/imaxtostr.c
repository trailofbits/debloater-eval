#define inttostr imaxtostr
#define inttype intmax_t
#define inttype_is_signed 1
#include "inttostr.c"
