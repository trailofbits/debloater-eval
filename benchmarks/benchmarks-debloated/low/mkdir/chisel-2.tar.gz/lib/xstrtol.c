

#ifndef __strtol
# define __strtol strtol
# define __strtol_t long int
#endif

#define ISSPACE(c) (IN_CTYPE_DOMAIN (c) && isspace (c))

#include "xstrtol.h"



/* FIXME: comment.  */

strtol_error
__xstrtol (const char *s, char **ptr, int strtol_base,
       __strtol_t *val, const char *valid_suffixes)
{
  char **p;
  __strtol_t tmp;
  strtol_error err = LONGINT_OK;
  tmp = __strtol (s, p, strtol_base);

  *val = tmp;
  return err;
}