

#include "modechange.h"
#include <sys/stat.h>
#include "xstrtol.h"
#include <stdlib.h>



/* The traditional octal values corresponding to each mode bit.  */
#define SUID 04000
#define SGID 02000
#define SVTX 01000
#define RUSR 00400
#define WUSR 00200
#define XUSR 00100
#define RGRP 00040
#define WGRP 00020
#define XGRP 00010
#define ROTH 00004
#define WOTH 00002
#define XOTH 00001
#define ALLM 07777 /* all octal mode bits */



/* All the mode bits that can be affected by chmod.  */
#define CHMOD_MODE_BITS \
  (S_ISUID | S_ISGID | S_ISVTX | S_IRWXU | S_IRWXG | S_IRWXO)

/* Return newly allocated memory to hold one element of type TYPE. */
#define talloc(type) ((type *) malloc (sizeof (type)))

/* Create a mode_change entry with the specified `=ddd'-style
   mode change operation, where NEW_MODE is `ddd'.  Return the
   new entry, or NULL upon failure.  */

static struct mode_change *
make_node_op_equals (mode_t new_mode)
{
  struct mode_change *p;
  p = talloc (struct mode_change);
  p->op = '=';
  p->value = new_mode;
  p->affected = CHMOD_MODE_BITS;	/* Affect all permissions. */
  return p;
}

/* Append entry E to the end of the link list with the specified
   HEAD and TAIL.  */

static void
mode_append_entry (struct mode_change **head,
           struct mode_change **tail,
           struct mode_change *e)
{
  if (*head == NULL)
    *head = *tail = e;

}

/* Return a linked list of file mode change operations created from
   MODE_STRING, an ASCII string that contains either an octal number
   specifying an absolute mode, or symbolic mode change operations with
   the form:
   [ugoa...][[+-=][rwxXstugo...]...][,...]
   MASKED_OPS is a bitmask indicating which symbolic mode operators (=+-)
   should not affect bits set in the umask when no users are given.
   Operators not selected in MASKED_OPS ignore the umask.

   Return MODE_INVALID if `mode_string' does not contain a valid
   representation of file mode change operations;
   return MODE_MEMORY_EXHAUSTED if there is insufficient memory. */

struct mode_change *
mode_compile (const char *mode_string, unsigned int masked_ops)
{
  struct mode_change *head;	/* First element of the linked list. */
  struct mode_change *tail;	/* An element of the linked list. */
  unsigned long octal_value;

  if (xstrtoul (mode_string, NULL, 8, &octal_value, "") == LONGINT_OK)
    {
      struct mode_change *p;
      mode_t mode;
      if (octal_value != (octal_value & ALLM))
    return MODE_INVALID;

      /* Help the compiler optimize the usual case where mode_t uses
	 the traditional octal representation.  */
      mode = ((S_ISUID == SUID && S_ISGID == SGID && S_ISVTX == SVTX
               && S_IRUSR == RUSR && S_IWUSR == WUSR && S_IXUSR == XUSR
               && S_IRGRP == RGRP && S_IWGRP == WGRP && S_IXGRP == XGRP
               && S_IROTH == ROTH && S_IWOTH == WOTH && S_IXOTH == XOTH)
          ? octal_value
          : (mode_t) ((octal_value & SUID ? S_ISUID : 0)
              | (octal_value & SGID ? S_ISGID : 0)
              | (octal_value & SVTX ? S_ISVTX : 0)
              | (octal_value & RUSR ? S_IRUSR : 0)
              | (octal_value & WUSR ? S_IWUSR : 0)
              | (octal_value & XUSR ? S_IXUSR : 0)
              | (octal_value & RGRP ? S_IRGRP : 0)
              | (octal_value & WGRP ? S_IWGRP : 0)
              | (octal_value & XGRP ? S_IXGRP : 0)
              | (octal_value & ROTH ? S_IROTH : 0)
              | (octal_value & WOTH ? S_IWOTH : 0)
              | (octal_value & XOTH ? S_IXOTH : 0)));

      p = make_node_op_equals (mode);
      mode_append_entry (&head, &tail, p);
      return head;
    }}

/* Return file mode OLDMODE, adjusted as indicated by the list of change
   operations CHANGES.  If OLDMODE is a directory, the type `X'
   change affects it even if no execute bits were set in OLDMODE.
   The returned value has the S_IFMT bits cleared. */

mode_t
mode_adjust (mode_t oldmode, const struct mode_change *changes)
{
  mode_t newmode;	/* The adjusted mode and one operand. */
  mode_t value;

  for (; changes; changes = changes->next)
    {
      if (changes->flags & MODE_COPY_EXISTING)
    ;
      else
    {
      value = changes->value;}

      switch (changes->op)
    {
    case '=':
	  /* Preserve the previous values in `newmode' of bits that are
	     not affected by this change operation. */
      newmode = (newmode & ~changes->affected) | value;}
    }
  return newmode;
}