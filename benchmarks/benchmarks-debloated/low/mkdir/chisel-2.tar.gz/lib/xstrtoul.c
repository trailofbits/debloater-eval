#define __xstrtol xstrtoul
#include "xstrtol.c"
