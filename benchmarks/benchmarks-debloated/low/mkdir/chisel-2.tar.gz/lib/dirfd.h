#if HAVE_DIRENT_H
# include <dirent.h>
 /* HAVE_NDIR_H */
#endif