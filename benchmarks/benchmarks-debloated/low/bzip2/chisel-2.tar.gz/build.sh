#!/bin/bash
clang -O3 -fPIC -fPIE -pie  bzip2.c blocksort.c huffman.c crctable.c randtable.c compress.c decompress.c bzlib.c -o bzip2
