#include "gzip.h"
#define EXTHDR 16               /* size of extended local header, inc sig */


          /* not used--needed to link crypt.c */
int pkzip = 0;

/* ===========================================================================
 * Unzip in to out.  This routine works on both gzip and pkzip files.
 *
 * IN assertions: the buffer inbuf contains already the beginning of
 *   the compressed data, from offsets inptr to insize-1 included.
 *   The magic header has already been checked. The output buffer is cleared.
 */
 unzip(in, out)   /* input and output file descriptors */
{       /* original uncompressed length */
    int n;
    uch buf[EXTHDR];
    ofd = out;

    /* Decompress */
    if (method == DEFLATED)  {

    int res = inflate();} 

    /* Get the crc and original length */
    if (!pkzip) {
        /* crc32  (see algorithm.doc)
	 * uncompressed input size modulo 2^32
         */
    for (n = 0; n < 8; n++) {
        buf[n] = (uch)get_byte(); /* may cause an error if EOF */
	}} }
