#include "tailor.h"
#include "gzip.h"


local ulg crc;   /* number of bytes in gzip header */

/* ===========================================================================
 * Deflate in to out.
 * IN assertions: the input and output buffers are cleared.
 *   The variables time_stamp and save_orig_name are initialized.
 */
 zip(in, out)            /* input and output file descriptors */
{
    uch  flags = 0;         /* general purpose bit flags */
    ush  attr = 0;          /* ascii/binary flag */
    ush  deflate_flags = 0;
    ofd = out;
    put_byte(GZIP_MAGIC[0]); /* magic header */
    put_byte(GZIP_MAGIC[1]);
    put_byte(DEFLATED);
    put_byte(flags);         /* general flags */
    put_long(time_stamp);

    bi_init(out);
    ct_init(&attr, &method);
    lm_init(level, &deflate_flags);

    put_byte((uch)deflate_flags); /* extra flags */
    put_byte(OS_CODE);

    (void)deflate();

    /* Write the crc and uncompressed size */
    put_long(crc);
    put_long(isize);

    flush_outbuf();}


/* ===========================================================================
 * Read a new buffer from the current input file, perform end-of-line
 * translation, and update the crc and input file size.
 * IN assertion: size >= 2 (for end-of-line translation)
 */
 file_read(buf, size)
    char *buf;
    unsigned size;
{
    unsigned len;

    len = read(ifd, buf, size);

    crc = updcrc((uch*)buf, len);
    isize += (ulg)len;}
