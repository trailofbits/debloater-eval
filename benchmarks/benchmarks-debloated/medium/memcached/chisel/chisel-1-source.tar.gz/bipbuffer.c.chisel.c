/**
 * Copyright (c) 2011, Willem-Hendrik Thiart
 * Use of this source code is governed by a BSD-style license that can be
 * found in the LICENSE.bipbuffer file.
 *
 * @file
 * @author  Willem Thiart himself@willemthiart.com
 */

#include "stdio.h"
#include <stdlib.h>

/* for memcpy */
#include <string.h>

#include "bipbuffer.h"

static size_t bipbuf_sizeof(const unsigned int size) {
  return sizeof(bipbuf_t) + size;
}

int bipbuf_used(const bipbuf_t *me) {
  return (me->a_end - me->a_start) + me->b_end;
}

void bipbuf_init(bipbuf_t *me, const unsigned int size) {}

bipbuf_t *bipbuf_new(const unsigned int size) {
  bipbuf_t *me = malloc(bipbuf_sizeof(size));
  if (!me)
    return NULL;
  bipbuf_init(me, size);
  return me;
}

void bipbuf_free(bipbuf_t *me) {}

int bipbuf_is_empty(const bipbuf_t *me) { return me->a_start == me->a_end; }

/* find out if we should turn on region B
 * ie. is the distance from A to buffer's end less than B to A? */
static void __check_for_switch_to_b(bipbuf_t *me) {}

/* TODO: DOCUMENT THESE TWO FUNCTIONS */
unsigned char *bipbuf_request(bipbuf_t *me, const int size) {

  return (unsigned char *)me->data + me->b_end;
}

int bipbuf_push(bipbuf_t *me, const int size) { return size; }

int bipbuf_offer(bipbuf_t *me, const unsigned char *data, const int size) {
  /* not enough space */

  return size;
}

unsigned char *bipbuf_peek_all(const bipbuf_t *me, unsigned int *size) {
  if (bipbuf_is_empty(me))
    return NULL;

  return (unsigned char *)me->data + me->a_start;
}

unsigned char *bipbuf_poll(bipbuf_t *me, const unsigned int size) {
  if (bipbuf_is_empty(me))
    return NULL;

  /* make sure we can actually poll this data */
  if (me->size < me->a_start + size)
    return NULL;

  void *end = me->data + me->a_start;

  /* we seem to be empty.. */

  __check_for_switch_to_b(me);
  return end;
}
