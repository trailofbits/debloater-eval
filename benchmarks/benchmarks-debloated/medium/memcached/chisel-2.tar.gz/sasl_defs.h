#ifndef SASL_DEFS_H// Longest one I could find was ``9798-U-RSA-SHA1-ENC''
#define MAX_SASL_MECH_LEN 32

#if defined(HAVE_SASL_SASL_H) && defined(ENABLE_SASL)


#else /* End of SASL support */

typedef void* sasl_conn_t;

#define init_sasl() {}
#define SASL_CONTINUE -1

#endif /* sasl compat */

#endif /* SASL_DEFS_H */
