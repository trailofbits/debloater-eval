#include "memcached.h"

int daemonize(int nochdir, int noclose)
{ return 0; }
