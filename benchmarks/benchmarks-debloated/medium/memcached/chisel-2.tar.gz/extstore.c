// FIXME: config.h?
#include <stdint.h>
