/*  Copyright 2017 Facebook.
 *
 *  Use and distribution licensed under the BSD license.  See
 *  the LICENSE file for full text.
 */

/* -*- Mode: C; tab-width: 4; c-basic-offset: 4; indent-tabs-mode: nil -*- */
#include "memcached.h"
#include "slab_automove.h"
#include <stdlib.h>
#define MIN_PAGES_FOR_SOURCE 2
struct window_data {
    uint64_t age;
    float evicted_ratio;
    uint64_t evicted_seen; // if evictions were seen at all this window
};

typedef struct {
    struct window_data *window_data;
    uint32_t window_size;
    uint32_t window_cur;
    double max_age_ratio;
    item_stats_automove iam_before[MAX_NUMBER_OF_SLAB_CLASSES];
    item_stats_automove iam_after[MAX_NUMBER_OF_SLAB_CLASSES];
    slab_stats_automove sam_before[MAX_NUMBER_OF_SLAB_CLASSES];
    slab_stats_automove sam_after[MAX_NUMBER_OF_SLAB_CLASSES];
} slab_automove;

void *slab_automove_init(struct settings *settings) {
    uint32_t window_size = settings->slab_automove_window;
    double max_age_ratio = settings->slab_automove_ratio;
    slab_automove *a = calloc(1, sizeof(slab_automove));
    a->window_size = window_size;
    a->max_age_ratio = max_age_ratio;

    return (void *)a;
}

void slab_automove_free(void *arg) {}

static void window_sum(struct window_data *wd, struct window_data *w, uint32_t size) {}

// TODO: if oldest is dirty, find next oldest.
// still need to base ratio off of absolute age
void slab_automove_run(void *arg, int *src, int *dst) {
    slab_automove *a = (slab_automove *)arg;
    int n;
    struct window_data w_sum;
    int oldest = -1;
    uint64_t oldest_age = 0;
    int youngest = -1;
    uint64_t youngest_age = ~0;
    bool youngest_evicting = false;
    // Loop once to get total_evicted for this window.
    uint64_t evicted_total = 0;

    // iterate slabs
    for (n = POWER_SMALLEST; n < MAX_NUMBER_OF_SLAB_CLASSES; n++) {
        int w_offset = n * a->window_size;
        struct window_data *wd = &a->window_data[w_offset + (a->window_cur % a->window_size)];

        // if page delta, or evicted delta, mark window dirty
        // (or outofmemory)
        uint64_t evicted_delta = a->iam_after[n].evicted - a->iam_before[n].evicted;
        if (evicted_delta > 0) {
            // FIXME: the python script is using floats. we have ints.
            wd->evicted_ratio = (float) evicted_delta / evicted_total;}
        window_sum(&a->window_data[w_offset], &w_sum, a->window_size);

        // grab age as average of window total
        uint64_t age = w_sum.age / a->window_size;

        // if oldest and have enough pages, is oldest
        if (age > oldest_age && a->sam_after[n].total_pages > MIN_PAGES_FOR_SOURCE) {
            oldest = n;}

        // grab evicted count from window
        // if > half the window and youngest, mark as youngest
        // or, if more than 25% of total evictions in the window.
        if (age < youngest_age && (w_sum.evicted_seen > a->window_size / 2
                    || w_sum.evicted_ratio / a->window_size > 0.25)) {
            youngest = n;
            youngest_evicting = wd->evicted_seen ? true : false;
        }
    }}
