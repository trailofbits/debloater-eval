/* Set to nonzero if you want to enable extstore */
#define EXTSTORE 1

/* Define to 1 if support getopt_long */
#define HAVE_GETOPT_LONG 1

/* Define to 1 if you have the `sandbox_init' function. */
/* #undef HAVE_SANDBOX_INIT */

/* we have sasl_callback_ft */
/* #undef HAVE_SASL_CALLBACK_FT */

/* Set to nonzero if your SASL implementation supports SASL_CB_GETCONF */
/* #undef HAVE_SASL_CB_GETCONF */

/* Set to nonzero if your SASL implementation supports SASL_CB_GETCONFPATH */
/* #undef HAVE_SASL_CB_GETCONFPATH */

/* Define to 1 if you have the <sasl/sasl.h> header file. */
/* #undef HAVE_SASL_SASL_H */

/* Define to 1 if you have the `setppriv' function. */
/* #undef HAVE_SETPPRIV */

/* Define to 1 if stdbool.h conforms to C99. */
#define HAVE_STDBOOL_H 1

/* Machine need alignment */
/* #undef NEED_ALIGN */

/* Name of package */
#define PACKAGE "memcached"

/* Set to nonzero if you want to enable proxy code */
/* #undef PROXY */

/* The size of `void *', as computed by sizeof. */
#define SIZEOF_VOID_P 8

/* Set to nonzero if you want to enable TLS */
/* #undef TLS */

/* Version number of package */
#define VERSION "UNKNOWN"



/* make sure IOV_MAX is defined */
#define _GNU_SOURCE 1

/* Define to empty if `const' does not conform to ANSI C. */
/* #undef const */

/* define to int if socklen_t not available */
/* #undef socklen_t */

#if HAVE_STDBOOL_H
#include <stdbool.h>
#endif 

#ifdef HAVE_INTTYPES_H
#include <inttypes.h>
#endif

