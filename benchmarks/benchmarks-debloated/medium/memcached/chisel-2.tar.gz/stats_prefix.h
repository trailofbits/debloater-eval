#ifndef STATS_PREFIX_H

/* Return the collected stats in a textual for suitable for writing to a client.
 * The size of the output text is stored in the length parameter.
 * Returns NULL on error
 */
char *stats_prefix_dump(int *length);

/* Visible for testing */
#define PREFIX_HASH_SIZE 256
typedef struct _prefix_stats PREFIX_STATS;
struct _prefix_stats {
    char *prefix;
    size_t prefix_len;
    uint64_t num_gets;
    uint64_t num_sets;
    uint64_t num_deletes;
    uint64_t num_hits;
    PREFIX_STATS *next;
};

/* Return the PREFIX_STATS structure for the specified key, creating it if
 * it does not already exist. Returns NULL if the key does not contain
 * prefix delimiter, or if there was an error. Requires you to have acquired
 * STATS_LOCK() first.
 */
PREFIX_STATS *stats_prefix_find(const char *key, const size_t nkey);

#endif
