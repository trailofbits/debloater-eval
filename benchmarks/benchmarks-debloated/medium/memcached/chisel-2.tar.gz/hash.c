/* -*- Mode: C; tab-width: 4; c-basic-offset: 4; indent-tabs-mode: nil -*- */

#include "memcached.h"
#include "murmur3_hash.h"
hash_func hash;

static uint32_t XXH3_hash(const void *key, size_t length) { return (uint32_t) 0; }

int hash_init(enum hashfunc_type type) {
    switch(type) {
        case JENKINS_HASH:
        case MURMUR3_HASH:
            hash = MurmurHash3_x86_32;
            break;
        case XXH3_HASH:
            hash = XXH3_hash;}
    return 0;
}
