#include "memcached.h"

static void display(const char *name, size_t size) {}

int main(int argc, char **argv) {
    display("Thread stats cumulative\t", sizeof(struct thread_stats));}
