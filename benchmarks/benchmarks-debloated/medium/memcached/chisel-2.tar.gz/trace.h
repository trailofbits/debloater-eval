#ifndef TRACE_H
#define TRACE_H

#ifdef ENABLE_DTRACE
#include "memcached_dtrace.h"
#else
#define MEMCACHED_ASSOC_DELETE(arg0, arg1)
#define MEMCACHED_COMMAND_DECR(arg0, arg1, arg2, arg3)
#define MEMCACHED_COMMAND_INCR(arg0, arg1, arg2, arg3)
#endif

#endif
