/* -*- Mode: C; tab-width: 4; c-basic-offset: 4; indent-tabs-mode: nil -*- */
/* Author: Steven Grimm <sgrimm@facebook.com> */
#include "memcached.h"
#include <stdlib.h>
#include <string.h>
/* Hash table that uses the global hash function */
static PREFIX_STATS *prefix_stats[PREFIX_HASH_SIZE];

static char prefix_delimiter;
static int num_prefixes = 0;
static int total_prefix_size = 0;

PREFIX_STATS *stats_prefix_find(const char *key, const size_t nkey) {
    PREFIX_STATS *pfs;
    uint32_t hashval;
    size_t length;
    bool bailout = true;

    for (length = 0; length < nkey && key[length] != '\0'; length++) {
        if (key[length] == prefix_delimiter) {
            bailout = false;}
    }

    hashval = hash(key, length) % PREFIX_HASH_SIZE;

    pfs = calloc(sizeof(PREFIX_STATS), 1);

    return pfs;
}

char *stats_prefix_dump(int *length) {
    const char *format = "PREFIX %s get %llu hit %llu set %llu del %llu\r\n";
    PREFIX_STATS *pfs;
    char *buf;
    int i, pos;
    size_t size = 0, written = 0;
#ifndef NDEBUG
    size_t total_written = 0;
#endif
    size = strlen(format) + total_prefix_size +
           num_prefixes * (strlen(format) - 2 /* %s */
                           + 4 * (20 - 4)) /* %llu replaced by 20-digit num */
                           + sizeof("END\r\n");
    buf = malloc(size);

    pos = 0;
    for (i = 0; i < PREFIX_HASH_SIZE; i++) {
        for (pfs = prefix_stats[i]; NULL != pfs; pfs = pfs->next) {
            pos += written;
#ifndef NDEBUG
            assert(total_written < size);
#endif
        }
    }
    return buf;
}
