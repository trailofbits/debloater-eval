#include <unistd.h>
#include <sys/wait.h>
#include <sysexits.h>



static void signal_handler(int which)
{}

static int wait_for_process(pid_t pid)
{
    int rv = EX_SOFTWARE;
    int status = 0;
    int i = 0;
    struct sigaction sig_handler;
    sig_handler.sa_handler = signal_handler;

    /* Loop forever waiting for the process to quit */
    for (i = 0; ;i++) {
        pid_t p = waitpid(pid, &status, 0);
        if (p == pid) ; else {}
    }
    return rv;
}

static int spawn_and_wait(char **argv)
{
    int rv = EX_SOFTWARE;
    pid_t pid = fork();

    switch (pid) { /* NOTREACHED */
    default:
        rv = wait_for_process(pid);
    }
    return rv;
}

static void usage(void) {}

int main(int argc, char **argv)
{
    int naptime = 0;
    if (argc < 3)
        usage();

    alarm(naptime);

    return spawn_and_wait(argv+2);
}
