#ifndef BIPBUFFER_H
#define BIPBUFFER_H

typedef struct
{
    unsigned long int size;

    /* region A */
    unsigned int a_start, a_end;

    /* region B */
    unsigned int b_end;

    /* is B inuse? */
    int b_inuse;

    unsigned char data[];
} bipbuf_t;

/**
 * Create a new bip buffer.
 *
 * malloc()s space
 *
 * @param[in] size The size of the buffer */
bipbuf_t *bipbuf_new(const unsigned int size);

/**
 * Look at data. Don't move cursor
 *
 * @param[in] len The length of the data returned
 * @return data on success, NULL if nothing available */
unsigned char *bipbuf_peek_all(const bipbuf_t* me, unsigned int *len);

/**
 * Get pointer to data to read. Move the cursor on.
 *
 * @param[in] len The length of the data to be polled
 * @return pointer to data, NULL if we can't poll this much data */
unsigned char *bipbuf_poll(bipbuf_t* me, const unsigned int size);

/**
 * @return how much space we have assigned */
int bipbuf_used(const bipbuf_t* cb);

#endif /* BIPBUFFER_H */
