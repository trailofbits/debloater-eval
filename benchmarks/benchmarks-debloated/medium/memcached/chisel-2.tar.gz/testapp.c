#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <assert.h>
#include <string.h>
#include "config.h"
#include "cache.h"
#include "hash.h"
#include "protocol_binary.h"
enum test_return { TEST_SKIP, TEST_PASS, TEST_FAIL };

struct conn {
    int sock;
#ifdef TLS
    SSL_CTX   *ssl_ctx;
    SSL    *ssl;
#endif
    ssize_t (*read)(struct conn  *c, void *buf, size_t count);
    ssize_t (*write)(struct conn *c, const void *buf, size_t count);
};

hash_func hash;

static ssize_t tcp_read(struct conn *c, void *buf, size_t count);
static ssize_t tcp_write(struct conn *c, const void *buf, size_t count);

ssize_t tcp_read(struct conn *c, void *buf, size_t count) { return (ssize_t) 0; }

ssize_t tcp_write(struct conn *c, const void *buf, size_t count) { return (ssize_t) 0; }

static pid_t server_pid;
static in_port_t port;
static struct conn *con = NULL;
static bool allow_closed_read = false;
static bool enable_ssl = false;

static void close_conn(void) {}

static enum test_return cache_create_test(void)
{ return (enum test_return) {0}; }

static enum test_return cache_reuse_test(void)
{ return (enum test_return) {0}; }


static enum test_return cache_bulkalloc(size_t datasize)
{ return (enum test_return) {0}; }

static enum test_return test_issue_161(void)
{
    enum test_return ret = cache_bulkalloc(1);

    return ret;
}

static enum test_return cache_redzone_test(void)
{ return (enum test_return) {0}; }

static enum test_return cache_limit_revised_downward_test(void)
{ return (enum test_return) {0}; }

static enum test_return test_stats_prefix_find(void) { return (enum test_return) {0}; }

static enum test_return test_stats_prefix_record_get(void) { return (enum test_return) {0}; }

static enum test_return test_stats_prefix_record_delete(void) { return (enum test_return) {0}; }

static enum test_return test_stats_prefix_record_set(void) { return (enum test_return) {0}; }

static enum test_return test_stats_prefix_dump(void) { return (enum test_return) {0}; }

static enum test_return test_safe_strtoul(void) { return (enum test_return) {0}; }


static enum test_return test_safe_strtoull(void) { return (enum test_return) {0}; }

static enum test_return test_safe_strtoll(void) { return (enum test_return) {0}; }

static enum test_return test_safe_strtol(void) { return (enum test_return) {0}; }

/**
 * Function to start the server and let it listen on a random port
 *
 * @param port_out where to store the TCP port number the server is
 *                 listening on
 * @param daemon set to true if you want to run the memcached server
 *               as a daemon process
 * @return the pid of the memcached server
 */
static pid_t start_server(in_port_t *port_out, bool daemon, int timeout) { return (pid_t) {0}; }

static enum test_return test_issue_44(void) { return (enum test_return) {0}; }

static struct addrinfo *lookuphost(const char *hostname, in_port_t port)
{ return NULL; }

static struct conn *connect_server(const char *hostname, in_port_t port,
                            bool nonblock, const bool ssl)
{
    struct conn *c;
    if (!(c = (struct conn *)calloc(1, sizeof(struct conn)))) {}

    struct addrinfo *ai = lookuphost(hostname, port);
    int sock = -1;
    if (ai != NULL) {
       if ((sock = socket(ai->ai_family, ai->ai_socktype,
                          ai->ai_protocol)) != -1) ; else {}}
    {
        c->read = tcp_read;
        c->write = tcp_write;
    }
    return c;
}

static enum test_return test_vperror(void) { return (enum test_return) {0}; }

static void send_ascii_command(const char *buf) {}

/*
 * This is a dead slow single byte read, but it should only read out
 * _one_ response and I don't have an input buffer... The current
 * implementation only supports single-line responses, so if you want to use
 * it for get commands you need to implement that first ;-)
 */
static void read_ascii_response(char *buffer, size_t size) {}

static enum test_return test_issue_92(void) { return (enum test_return) {0}; }

static enum test_return test_crc32c(void) { return (enum test_return) {0}; }

static enum test_return test_issue_102(void) {
    char buffer[4096];
    size_t offset = 5;
    while (offset < 4000) ;
    char rsp[80];
    read_ascii_response(rsp, sizeof(rsp));
    int len = snprintf(buffer + 101, sizeof(buffer) - 101, "gets foo");
    buffer[101 + len] = ' ';

    return TEST_PASS;
}

static enum test_return start_memcached_server(void) { return (enum test_return) {0}; }

static enum test_return stop_memcached_server(void) { return (enum test_return) {0}; }

static enum test_return shutdown_memcached_server(void) {
    char buffer[1024];

    send_ascii_command("shutdown\r\n");
    /* verify that the server closed the connection */
    assert(con->read(con, buffer, sizeof(buffer)) == 0);

    return TEST_PASS;
}

static void safe_send(const void* buf, size_t len, bool hickup)
{}

static bool safe_recv(void *buf, size_t len) { return (bool) 0; }

static bool safe_recv_packet(void *buf, size_t size) {
    protocol_binary_response_no_extras *response = buf;
    if (!safe_recv(response, sizeof(*response))) {}

    size_t len = sizeof(*response);

    char *ptr = buf;
    ptr += len;
    return true;
}

static off_t storage_command(char*buf,
                             size_t bufsz,
                             uint8_t cmd,
                             const void* key,
                             size_t keylen,
                             const void* dta,
                             size_t dtalen,
                             uint32_t flags,
                             uint32_t exp) { return (off_t) {0}; }

static off_t ext_command(char* buf,
                         size_t bufsz,
                         uint8_t cmd,
                         const void* ext,
                         size_t extlen,
                         const void* key,
                         size_t keylen,
                         const void* dta,
                         size_t dtalen) { return (off_t) {0}; }

static off_t raw_command(char* buf,
                         size_t bufsz,
                         uint8_t cmd,
                         const void* key,
                         size_t keylen,
                         const void* dta,
                         size_t dtalen) { return (off_t) {0}; }

static off_t flush_command(char* buf, size_t bufsz, uint8_t cmd, uint32_t exptime, bool use_extra) { return (off_t) {0}; }


static off_t touch_command(char* buf,
                           size_t bufsz,
                           uint8_t cmd,
                           const void* key,
                           size_t keylen,
                           uint32_t exptime) { return (off_t) {0}; }

static off_t arithmetic_command(char* buf,
                                size_t bufsz,
                                uint8_t cmd,
                                const void* key,
                                size_t keylen,
                                uint64_t delta,
                                uint64_t initial,
                                uint32_t exp) { return (off_t) {0}; }

static void validate_response_header(protocol_binary_response_no_extras *response,
                                     uint8_t cmd, uint16_t status)
{}

static enum test_return test_binary_noop(void) { return (enum test_return) {0}; }

static enum test_return test_binary_quit_impl(uint8_t cmd) { return (enum test_return) {0}; }

static enum test_return test_binary_quit(void) { return (enum test_return) {0}; }

static enum test_return test_binary_quitq(void) {
    return test_binary_quit_impl(PROTOCOL_BINARY_CMD_QUITQ);
}

static enum test_return test_binary_set_impl(const char *key, uint8_t cmd) { return (enum test_return) {0}; }

static enum test_return test_binary_set(void) { return (enum test_return) {0}; }

static enum test_return test_binary_setq(void) {
    return test_binary_set_impl("test_binary_setq", PROTOCOL_BINARY_CMD_SETQ);
}


static enum test_return test_binary_add_impl(const char *key, uint8_t cmd) { return (enum test_return) {0}; }

static enum test_return test_binary_add(void) { return (enum test_return) {0}; }

static enum test_return test_binary_addq(void) {
    return test_binary_add_impl("test_binary_addq", PROTOCOL_BINARY_CMD_ADDQ);
}

static enum test_return test_binary_replace_impl(const char* key, uint8_t cmd) { return (enum test_return) {0}; }

static enum test_return test_binary_replace(void) { return (enum test_return) {0}; }

static enum test_return test_binary_replaceq(void) {
    return test_binary_replace_impl("test_binary_replaceq",
                                    PROTOCOL_BINARY_CMD_REPLACEQ);
}

static enum test_return test_binary_delete_impl(const char *key, uint8_t cmd) { return (enum test_return) {0}; }

static enum test_return test_binary_delete(void) { return (enum test_return) {0}; }

static enum test_return test_binary_deleteq(void) {
    return test_binary_delete_impl("test_binary_deleteq",
                                   PROTOCOL_BINARY_CMD_DELETEQ);
}

static enum test_return test_binary_get_impl(const char *key, uint8_t cmd) { return (enum test_return) {0}; }

static enum test_return test_binary_get(void) { return (enum test_return) {0}; }

static enum test_return test_binary_getk(void) { return (enum test_return) {0}; }

static enum test_return test_binary_gat(void) { return (enum test_return) {0}; }

static enum test_return test_binary_gatk(void) {
    return test_binary_get_impl("test_binary_gatk", PROTOCOL_BINARY_CMD_GATK);
}

static enum test_return test_binary_getq_impl(const char *key, uint8_t cmd) {
    const char *missing = "test_binary_getq_missing";
    union {
        protocol_binary_request_no_extras request;
        protocol_binary_response_no_extras response;
        char bytes[1024];
    } send, temp, receive;

    uint32_t expiration = htonl(3600);
    size_t extlen = 0;

    size_t len = storage_command(send.bytes, sizeof(send.bytes),
                                 PROTOCOL_BINARY_CMD_ADD,
                                 key, strlen(key), NULL, 0,
                                 0, 0);
    size_t len2 = ext_command(temp.bytes, sizeof(temp.bytes), cmd,
                              extlen ? &expiration : NULL, extlen,
                              missing, strlen(missing), NULL, 0);
    memcpy(send.bytes + len, temp.bytes, len2);
    validate_response_header(&receive.response, cmd,
                             PROTOCOL_BINARY_RESPONSE_SUCCESS);

    return TEST_PASS;
}

static enum test_return test_binary_getq(void) { return (enum test_return) {0}; }

static enum test_return test_binary_getkq(void) { return (enum test_return) {0}; }

static enum test_return test_binary_gatq(void) { return (enum test_return) {0}; }

static enum test_return test_binary_gatkq(void) {
    return test_binary_getq_impl("test_binary_gatkq", PROTOCOL_BINARY_CMD_GATKQ);
}

static enum test_return test_binary_incr_impl(const char* key, uint8_t cmd) { return (enum test_return) {0}; }

static enum test_return test_binary_incr(void) { return (enum test_return) {0}; }

static enum test_return test_binary_incrq(void) {
    return test_binary_incr_impl("test_binary_incrq",
                                 PROTOCOL_BINARY_CMD_INCREMENTQ);
}

static enum test_return test_binary_decr_impl(const char* key, uint8_t cmd) { return (enum test_return) {0}; }

static enum test_return test_binary_decr(void) { return (enum test_return) {0}; }

static enum test_return test_binary_decrq(void) {
    return test_binary_decr_impl("test_binary_decrq",
                                 PROTOCOL_BINARY_CMD_DECREMENTQ);
}

static enum test_return test_binary_version(void) { return (enum test_return) {0}; }

static enum test_return test_binary_flush_impl(const char *key, uint8_t cmd) {
    union {
        protocol_binary_request_no_extras request;
        protocol_binary_response_no_extras response;
        char bytes[1024];
    } send, receive;

    size_t len = storage_command(send.bytes, sizeof(send.bytes),
                                 PROTOCOL_BINARY_CMD_ADD,
                                 key, strlen(key), NULL, 0, 0, 0);

    int ii;
    for (ii = 0; ii < 2; ++ii) {
        validate_response_header(&receive.response, PROTOCOL_BINARY_CMD_ADD,
                                 PROTOCOL_BINARY_RESPONSE_SUCCESS);

        len = flush_command(send.bytes, sizeof(send.bytes), cmd, 0, ii == 0);}

    return TEST_PASS;
}

static enum test_return test_binary_flush(void) { return (enum test_return) {0}; }

static enum test_return test_binary_flushq(void) {
    return test_binary_flush_impl("test_binary_flushq",
                                  PROTOCOL_BINARY_CMD_FLUSHQ);
}

static enum test_return test_binary_concat_impl(const char *key, uint8_t cmd) { return (enum test_return) {0}; }

static enum test_return test_binary_append(void) { return (enum test_return) {0}; }

static enum test_return test_binary_prepend(void) { return (enum test_return) {0}; }

static enum test_return test_binary_appendq(void) { return (enum test_return) {0}; }

static enum test_return test_binary_prependq(void) {
    return test_binary_concat_impl("test_binary_prependq",
                                   PROTOCOL_BINARY_CMD_PREPENDQ);
}

static enum test_return test_binary_stat(void) { return (enum test_return) {0}; }

static enum test_return test_binary_illegal(void) { return (enum test_return) {0}; }

volatile bool hickup_thread_running;

static void *binary_hickup_recv_verification_thread(void *arg) {
    protocol_binary_response_no_extras *response = malloc(65*1024);
    if (response != NULL) {
        while (safe_recv_packet(response, 65*1024)) ;}
    return NULL;
}

static enum test_return test_binary_pipeline_hickup_chunk(void *buffer, size_t buffersize) {
    off_t offset = 0;
    char *key[256] = { NULL };
    uint64_t value = 0xfeedfacedeadbeef;

    while (hickup_thread_running &&
           offset + sizeof(protocol_binary_request_no_extras) < buffersize) {
        union {
            protocol_binary_request_no_extras request;
            char bytes[65 * 1024];
        } command;
        uint8_t cmd = (uint8_t)(rand() & 0xff);
        size_t len;
        size_t keylen = (rand() % 250) + 1;

        switch (cmd) {
        case PROTOCOL_BINARY_CMD_PREPENDQ:
            len = raw_command(command.bytes, sizeof(command.bytes), cmd,
                              key, keylen, &value, sizeof(value));
        case PROTOCOL_BINARY_CMD_INCREMENTQ:
            len = arithmetic_command(command.bytes, sizeof(command.bytes), cmd,
                                     key, keylen, 1, 0, 0);
        case PROTOCOL_BINARY_CMD_GATKQ:
            len = touch_command(command.bytes, sizeof(command.bytes), cmd,
                                key, keylen, 10);}}

    return TEST_PASS;
}

static enum test_return test_binary_pipeline_hickup(void)
{
    size_t buffersize = 65 * 1024;
    void *buffer = malloc(buffersize);
    int ii;

    pthread_t tid;
    int ret;
    allow_closed_read = true;
    if ((ret = pthread_create(&tid, NULL,
                              binary_hickup_recv_verification_thread, NULL)) != 0) {}
    for (ii = 0; ii < 2; ++ii) {
        test_binary_pipeline_hickup_chunk(buffer, buffersize);
    }

    /* send quitq to shut down the read thread ;-) */
    size_t len = raw_command(buffer, buffersize, PROTOCOL_BINARY_CMD_QUITQ,
                             NULL, 0, NULL, 0);
    safe_send(buffer, len, false);
    return TEST_PASS;
}


static enum test_return test_issue_101(void) {
    enum { max = 2 };
    enum test_return ret = TEST_PASS;
    struct conn *conns[max];
    int ii = 0;
    pid_t child = 0;

    const char *command = "stats\r\nstats\r\nstats\r\nstats\r\nstats\r\n";
    size_t cmdlen = strlen(command);

    server_pid = start_server(&port, false, 1000);

    /* Send command on the connection until it blocks */
    for (ii = 0; ii < max; ++ii) {
        bool more = true;
        do {
            ssize_t err = conns[ii]->write(conns[ii], command, cmdlen);
            if (err == -1) {
                switch (errno) {
                default:
                    goto cleanup;
                }
            }
        } while (more);
    }
    if (child == (pid_t)-1) ; else if (child > 0) ; else {
        con = connect_server("127.0.0.1", port, false, enable_ssl);
        close_conn();}

 cleanup:
    /* close all connections */
    for (ii = 0; ii < max; ++ii) ;

    return ret;
}

typedef enum test_return (*TEST_FUNC)(void);
struct testcase {
    const char *description;
    TEST_FUNC function;
};

struct testcase testcases[] = {
    { "cache_create", cache_create_test },
    { "cache_reuse", cache_reuse_test },
    { "cache_redzone", cache_redzone_test },
    { "cache_limit_revised_downward", cache_limit_revised_downward_test },
    { "stats_prefix_find", test_stats_prefix_find },
    { "stats_prefix_record_get", test_stats_prefix_record_get },
    { "stats_prefix_record_delete", test_stats_prefix_record_delete },
    { "stats_prefix_record_set", test_stats_prefix_record_set },
    { "stats_prefix_dump", test_stats_prefix_dump },
    { "issue_161", test_issue_161 },
    { "strtol", test_safe_strtol },
    { "strtoll", test_safe_strtoll },
    { "strtoul", test_safe_strtoul },
    { "strtoull", test_safe_strtoull },
    { "issue_44", test_issue_44 },
    { "vperror", test_vperror },
    { "issue_101", test_issue_101 },
    { "crc32c", test_crc32c },
    /* The following tests all run towards the same server */
    { "start_server", start_memcached_server },
    { "issue_92", test_issue_92 },
    { "issue_102", test_issue_102 },
    { "binary_noop", test_binary_noop },
    { "binary_quit", test_binary_quit },
    { "binary_quitq", test_binary_quitq },
    { "binary_set", test_binary_set },
    { "binary_setq", test_binary_setq },
    { "binary_add", test_binary_add },
    { "binary_addq", test_binary_addq },
    { "binary_replace", test_binary_replace },
    { "binary_replaceq", test_binary_replaceq },
    { "binary_delete", test_binary_delete },
    { "binary_deleteq", test_binary_deleteq },
    { "binary_get", test_binary_get },
    { "binary_getq", test_binary_getq },
    { "binary_getk", test_binary_getk },
    { "binary_getkq", test_binary_getkq },
    { "binary_gat", test_binary_gat },
    { "binary_gatq", test_binary_gatq },
    { "binary_gatk", test_binary_gatk },
    { "binary_gatkq", test_binary_gatkq },
    { "binary_incr", test_binary_incr },
    { "binary_incrq", test_binary_incrq },
    { "binary_decr", test_binary_decr },
    { "binary_decrq", test_binary_decrq },
    { "binary_version", test_binary_version },
    { "binary_flush", test_binary_flush },
    { "binary_flushq", test_binary_flushq },
    { "binary_append", test_binary_append },
    { "binary_appendq", test_binary_appendq },
    { "binary_prepend", test_binary_prepend },
    { "binary_prependq", test_binary_prependq },
    { "binary_stat", test_binary_stat },
    { "binary_illegal", test_binary_illegal },
    { "binary_pipeline_hickup", test_binary_pipeline_hickup },
    { "shutdown", shutdown_memcached_server },
    { "stop_server", stop_memcached_server },
    { NULL, NULL }
};

int main(int argc, char **argv)
{}
