#include <stdlib.h>

#include "bipbuffer.h"

static size_t bipbuf_sizeof(const unsigned int size)
{ return (size_t) 0; }

int bipbuf_used(const bipbuf_t* me)
{ return 0; }

bipbuf_t *bipbuf_new(const unsigned int size)
{
    bipbuf_t *me = malloc(bipbuf_sizeof(size));
    return me;
}

/* find out if we should turn on region B
 * ie. is the distance from A to buffer's end less than B to A? */
static void __check_for_switch_to_b(bipbuf_t* me)
{}

unsigned char *bipbuf_peek_all(const bipbuf_t* me, unsigned int *size)
{
    return (unsigned char*)me->data + me->a_start;
}

unsigned char *bipbuf_poll(bipbuf_t* me, const unsigned int size)
{

    void *end = me->data + me->a_start;

    __check_for_switch_to_b(me);
    return end;
}
