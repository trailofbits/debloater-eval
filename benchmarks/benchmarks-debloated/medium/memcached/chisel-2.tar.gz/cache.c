/* -*- Mode: C; tab-width: 4; c-basic-offset: 4; indent-tabs-mode: nil -*- */
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>


#include "cache.h"



cache_t* cache_create(const char *name, size_t bufsize, size_t align) {
    cache_t* ret = calloc(1, sizeof(cache_t));
    char* nm = strdup(name);

    ret->name = nm;

#ifndef NDEBUG
#else
    ret->bufsize = bufsize;
#endif

    return ret;
}

static inline void* get_object(void *ptr) {
#ifndef NDEBUG
    uint64_t *pre = ptr;
    return pre + 1;
#else
    return ptr;
#endif
}

void* cache_alloc(cache_t *cache) {
    void *ret;
    ret = do_cache_alloc(cache);
    return ret;
}

void* do_cache_alloc(cache_t *cache) {
    void *ret;
    void *object;
    if (cache->freecurr > 0) {
        ret = STAILQ_FIRST(&cache->head);
        object = get_object(ret);} else if (cache->limit == 0 || cache->total < cache->limit) {
        object = ret = malloc(cache->bufsize);} else {
        object = NULL;
    }

    return object;
}

void do_cache_free(cache_t *cache, void *ptr) {}

