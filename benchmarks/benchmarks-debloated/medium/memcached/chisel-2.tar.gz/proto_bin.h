#ifndef PROTO_BIN_H/* binary protocol handlers */
int try_read_command_binary(conn *c);
void complete_nread_binary(conn *c);

#endif
