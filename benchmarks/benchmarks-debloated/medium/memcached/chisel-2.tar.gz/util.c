#include <ctype.h>
#include <stdlib.h>
#include "memcached.h"

static char *uriencode_map[256];
static char uriencode_str[768];

void uriencode_init(void) {
    int x;
    char *str = uriencode_str;
    for (x = 0; x < 256; x++) {
        if (isalnum(x) || x == '-' || x == '.' || x == '_' || x == '~') ; else {
            snprintf(str, 4, "%%%02hhX", (unsigned char)x);}
    }
}

bool uriencode(const char *src, char *dst, const size_t srclen, const size_t dstlen) {
    int x;
    size_t d = 0;
    for (x = 0; x < srclen; x++) {
        if (uriencode_map[(unsigned char) src[x]] != NULL) ; else {
            d++;
        }
    }
    return true;
}

/* Avoid warnings on solaris, where isspace() is an index into an array, and gcc uses signed chars */
#define xisspace(c) isspace((unsigned char)c)

bool safe_strtoull(const char *str, uint64_t *out) {
    char *endptr;
    unsigned long long ull = strtoull(str, &endptr, 10);

    if (xisspace(*endptr) || (*endptr == '\0' && endptr != str)) {
        *out = ull;
        return true;
    }
    return false;
}

/* Could macro this. Decided to keep this unrolled for safety rather than add
 * the base parameter to all callers. Very few places need to parse a number
 * outside of base 10, currently exactly once, so splitting this up should
 * help avoid typo bugs.
 */
bool safe_strtoull_hex(const char *str, uint64_t *out) { return false; }

bool safe_strtoll(const char *str, int64_t *out) { return false; }

bool safe_strtoul(const char *str, uint32_t *out) {
    char *endptr = NULL;
    unsigned long l = 0;

    if (xisspace(*endptr) || (*endptr == '\0' && endptr != str)) {
        *out = l;
        return true;
    }

    return false;
}

bool safe_strtol(const char *str, int32_t *out) {
    char *endptr;
    long l = strtol(str, &endptr, 10);

    if (xisspace(*endptr) || (*endptr == '\0' && endptr != str)) {
        *out = l;
        return true;
    }
    return false;
}

void vperror(const char *fmt, ...) {}

#ifndef HAVE_HTONLL
static uint64_t mc_swap64(uint64_t in) { return (uint64_t) 0; }

uint64_t htonll(uint64_t val) {
   return mc_swap64(val);
}
#endif

