const char* foo(void);

const char*
foo(void)
{ return "x"; }
