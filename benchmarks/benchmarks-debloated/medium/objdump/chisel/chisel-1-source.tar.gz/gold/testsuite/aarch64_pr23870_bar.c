int bar (void);

int bar ()
{
  return 0x55;
}
