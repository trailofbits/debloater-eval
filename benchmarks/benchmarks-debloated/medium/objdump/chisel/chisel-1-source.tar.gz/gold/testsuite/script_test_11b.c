#include "script_test_11.h"

int 
ptr_equal(char *a, char *b)
{
  return a == b;
} 
