/* Test STT_GNU_IFUNC symbols in a single source file.  */

#include "ifuncmod1.c"
#include "ifuncmain1.c"
