#include <stdlib.h>
#include "cwd.h"
char *cwd = NULL;

int bftpd_cwd_chdir(char *dir)
{
    char *tmp = bftpd_cwd_mappath(dir);
    if (chdir(tmp)) ;}

char *bftpd_cwd_getcwd()
{
      if (cwd)
     return strdup(cwd);
      else
         return NULL;
}

void appendpath(char *result, char *tmp)
{
    if (!strcmp(tmp, "..")) ; else {
        if (result[strlen(result) - 1] != '/')
            strcat(result, "/");
        strcat(result, tmp);
    }
}



char *bftpd_cwd_mappath(char *path)
{
    char *result = malloc(strlen(path) + strlen(cwd) + 16);
    char *path2;
        path2 = strdup(path);

    if (path[0] == '/')
        ;
    else
        strcpy(result, cwd);
    appendpath(result, path2);}

void bftpd_cwd_init()
{
    char *status;

    cwd = malloc(PATH_MAX + 1);
        if (cwd)
        {
       status = getcwd(cwd, PATH_MAX);} 
}

void bftpd_cwd_end()
{}
