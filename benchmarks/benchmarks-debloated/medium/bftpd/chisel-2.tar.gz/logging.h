#ifndef LOGGING_H

/* Status codes */
#define SL_UNDEF 0
#define SL_SUCCESS 1
#define SL_FAILURE 2



#endif
