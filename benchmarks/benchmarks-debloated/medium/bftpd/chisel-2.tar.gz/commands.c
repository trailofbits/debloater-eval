#include "config.h"
#include <stdio.h>

#ifdef HAVE_SYS_STAT_H
#include <sys/stat.h>
#endif
#ifdef HAVE_ARPA_INET_H
#include <arpa/inet.h>
#endif
#ifdef HAVE_TIME_H
#include <time.h>
#endif
#include <fcntl.h>


#include "mystring.h"
#include "login.h"
#include "logging.h"
#include "options.h"
#include "main.h"
#include "targzip.h"
#include "cwd.h"


int state = STATE_CONNECTED;
char user[USERLEN + 1];
char pasv = 0;
int sock;
int pasvsock = -1;
char *philename = NULL;
short int xfertype = TYPE_BINARY;
int xfer_bufsize;


void control_printf(char success, char *format, ...)
{
    char buffer[MAX_STRING_LENGTH];
    va_list val;
    va_start(val, format);
    vsnprintf(buffer, sizeof(buffer), format, val);
    fprintf(stderr, "%s\r\n", buffer);}

int dataconn()
{
    struct sockaddr foo;
    struct sockaddr_in local;
    socklen_t namelen = sizeof(foo);
        int curuid = geteuid();

    if (pasv) {
        sock = accept(pasvsock, (struct sockaddr *) &foo, (socklen_t *) &namelen);} 
    control_printf(SL_SUCCESS, "150 %s data connection established.",
                   xfertype == TYPE_BINARY ? "BINARY" : "ASCII");
    return 0;
}

void command_user(char *username)
{
    mystrncpy(user, username, sizeof(user) - 1);
        userinfo_set = 1;
    if (!strcasecmp(config_getoption("ANONYMOUS_USER"), "yes"))
        {
                state = STATE_USER;
                control_printf(SL_SUCCESS, "331 Password please.");
        }

}

void command_pass(char *password)
{
    if (bftpd_login(password)) ;
}

void command_pwd(char *params)
{
     char *my_cwd = NULL;

     my_cwd = bftpd_cwd_getcwd();
     if (my_cwd)
     {
         control_printf(SL_SUCCESS, "257 \"%s\" is the current working directory.", my_cwd);}
}


void command_type(char *params)
{
    if ((*params == 'A') || (*params == 'a')) ; else if ((*params == 'I') || (*params == 'i')) {
          control_printf(SL_SUCCESS, "200 Transfer type changed to BINARY");} 
}

void command_port(char *params) {}

void command_eprt(char *params) {}

void command_pasv(char *foo)
{
    int a1, a2, a3, a4;
        socklen_t namelen;
    struct sockaddr_in localsock;
    pasvsock = socket(AF_INET, SOCK_STREAM, 0);
    if (listen(pasvsock, 1)) ;
    getsockname(pasvsock, (struct sockaddr *) &localsock, (socklen_t *) &namelen);

    control_printf(SL_SUCCESS, "227 Entering Passive Mode (%i,%i,%i,%i,%i,%i)", a1, a2, a3, a4,
             ntohs(localsock.sin_port) >> 8, ntohs(localsock.sin_port) & 0xFF);
    pasv = 1;
}

void command_epsv(char *params)
{}

void command_allo(char *foo)
{
    command_noop(foo);
}


/* This function allows the storage of multiple files on the server. */
void command_mput(char *filenames)
{}



void do_stor(char *filename, int flags)
{
    char *buffer;
    int fd = -1, i, max;
    char *mapped = bftpd_cwd_mappath(filename);

    int my_buffer_size;
    int attempt_gzip = FALSE;
    int change_buffer_size = FALSE;
    int stdin_fileno;
    int write_result;

        if (! attempt_gzip)
        {        
      fd = open(mapped, flags, 00666);}
    if (dataconn())
        ;

    /* Figure out how big the transfer buffer should be.
       This will be the total size divided by the number of clients connected.
       -- Jesse
    */
    if (change_buffer_size)
    ;
    else
       my_buffer_size = xfer_bufsize;
    for (;;)       /* start receiving loop */ 
        {

    if (!((i = recv(sock, buffer, my_buffer_size - 1, 0))))
            break;
           if(! attempt_gzip)
           {
              write_result = write(fd, buffer, i);}}
    control_printf(SL_SUCCESS, "226 File transmission successful.");

        if (mapped)
           ;
        // Update_Send_Recv(user, bytes_sent, bytes_recvd);
}

void command_stor(char *filename)
{
    do_stor(filename, O_CREAT | O_WRONLY | O_TRUNC);
}

void command_appe(char *filename)
{}




/* Send multpile files to the client. */
void command_mget(char *filenames)
{}

void command_retr(char *filename)
{
        int num_clients = 1;
        int new_num_clients;      /* number of connections to the server */
        int my_buffer_size;       /* size of the transfer buffer to use */
    char *mapped = NULL;
    char *buffer;
        int xfer_delay;
        struct timeval wait_time;
        ssize_t send_status;
        int change_buffer_size = FALSE;
    int phile;
    ssize_t i;
        int whattodo = DO_NORMAL;

    mapped = bftpd_cwd_mappath(filename);

    phile = open(mapped, O_RDONLY);
    switch (whattodo) {

        case DO_NORMAL:
            if (dataconn())
                ;
            buffer = malloc(xfer_bufsize * 2 + 1);

                        i = read(phile, buffer, my_buffer_size);
            while (i > 0) {
                send_status = send(sock, buffer, i, 0);
                                i = read(phile, buffer, my_buffer_size);
            }
    }
    close(sock);
    control_printf(SL_SUCCESS, "226 File transmission successful.");}

void do_dirlist(char *dirname, char verbose)
{
        int show_hidden = FALSE;
    FILE *datastream;
    if (dataconn())
        ;
    datastream = fdopen(sock, "w");
    if (dirname[0] == '\0')
        dirlist("*", datastream, verbose, show_hidden);

    fclose(datastream);
    control_printf(SL_SUCCESS, "226 Directory list has been submitted.");
}

void command_list(char *dirname)
{
    do_dirlist(dirname, 1);
}

void command_nlst(char *dirname)
{}

void command_syst(char *params)
{}

void command_mdtm(char *filename)
{
    struct stat statbuf;
    struct tm *filetime;
    char *fullfilename = bftpd_cwd_mappath(filename);
    if (!stat(fullfilename, (struct stat *) &statbuf)) {
        control_printf(SL_SUCCESS, "213 %04i%02i%02i%02i%02i%02i",
                filetime->tm_year + 1900, filetime->tm_mon + 1,
                filetime->tm_mday, filetime->tm_hour, filetime->tm_min,
                filetime->tm_sec);
    } }

void command_cwd(char *dir)
{
    if (bftpd_cwd_chdir(dir)) ; else {
        control_printf(SL_SUCCESS, "250 OK");
    }
}

void command_cdup(char *params)
{}

void command_dele(char *filename)
{
        struct stat sbuf;
    char *mapped = bftpd_cwd_mappath(filename);

        /*
	if (unlink(mapped)) {
		bftpd_log("Error: '%s' while trying to delete file '%s'.\n",
				  strerror(errno), filename);
        */
        if ( lstat(mapped, &sbuf) == -1 ) ; else {
        /*
		bftpd_log("Deleted file '%s'.\n", filename);
		control_printf(SL_SUCCESS, "200 OK");
        */
                if (S_ISDIR(sbuf.st_mode))
                ;
                else
                {
                   if (unlink(mapped))
                   ;
                   else
                   {
                        control_printf(SL_SUCCESS, "200 OK");
                   }
                }
        }}

void command_mkd(char *dirname)
{
    char *mapped = bftpd_cwd_mappath(dirname);

    if (mkdir(mapped, 0777)) ; else {
        control_printf(SL_SUCCESS, "257 \"%s\" has been created.", dirname);
    }}

void command_rmd(char *dirname)
{
    char *mapped = bftpd_cwd_mappath(dirname);

    if (rmdir(mapped)) ; else {
        control_printf(SL_SUCCESS, "250 OK");
    }}

void command_noop(char *params)
{
    control_printf(SL_SUCCESS, "200 OK");
}

void command_rnfr(char *oldname)
{
    FILE *file;
    char *mapped = bftpd_cwd_mappath(oldname);

    if ((file = fopen(mapped, "r"))) {
        philename = mapped;
        state = STATE_RENAME;
        control_printf(SL_SUCCESS, "350 File exists, ready for destination name");
    } 
}

void command_rnto(char *newname)
{
    char *mapped = bftpd_cwd_mappath(newname);

    if (rename(philename, mapped)) ; else {
        control_printf(SL_SUCCESS, "250 OK");}}

void command_rest(char *params)
{}

void command_size(char *filename)
{
    struct stat statbuf;
    char *mapped = bftpd_cwd_mappath(filename);

    if (!stat(mapped, &statbuf)) {
        control_printf(SL_SUCCESS, "213 %lld", (long long) statbuf.st_size);
    } }

void command_quit(char *params)
{
    control_printf(SL_SUCCESS, "221 %s", config_getoption("QUIT_MSG"));}

void command_stat(char *filename)
{}

/* SITE commands */

void command_chmod(char *params)
{
    int permissions;
    char *mapped;
        char *my_string;
        my_string = strdup(strchr(params, ' ') + 1);
	/* mapped = bftpd_cwd_mappath(strdup(strchr(params, ' ') + 1)); */
        mapped = bftpd_cwd_mappath(my_string);
    sscanf(params, "%o", &permissions);
    if (chmod(mapped, permissions))
        ;
    else {
        control_printf(SL_SUCCESS, "200 CHMOD successful.");
        }}

void command_chown(char *params)
{}




/*
Send the md5sum check of a given file to the
client.
*/
void command_md5(char *philename)
{}



void command_site(char *str)
{
    const struct command subcmds[] = {
        {"chmod ", NULL, command_chmod, STATE_AUTHENTICATED},
        {"chown ", NULL, command_chown, STATE_AUTHENTICATED},
                {"md5", NULL, command_md5, STATE_AUTHENTICATED},
        {NULL, NULL, 0}
    };
    int i;
    for (i = 0; subcmds[i].name; i++) {
        if (!strncasecmp(str, subcmds[i].name, strlen(subcmds[i].name))) {
            cutto(str, strlen(subcmds[i].name));
            subcmds[i].function(str);}
    }
    control_printf(SL_FAILURE, "550 Unknown command: 'SITE %s'.", str);
}

/* Command parsing */

const struct command commands[] = {
    {"USER", "<sp> username", command_user, STATE_CONNECTED, 0},
    {"PASS", "<sp> password", command_pass, STATE_USER, 0},
    {"XPWD", "(returns cwd)", command_pwd, STATE_AUTHENTICATED, 1},
    {"PWD", "(returns cwd)", command_pwd, STATE_AUTHENTICATED, 0},
    {"TYPE", "<sp> type-code (A or I)", command_type, STATE_AUTHENTICATED, 0},
    {"PORT", "<sp> h1,h2,h3,h4,p1,p2", command_port, STATE_AUTHENTICATED, 0},
    {"EPRT", "<sp><d><net-prt><d><ip><d><tcp-prt><d>", command_eprt, STATE_AUTHENTICATED, 1},
    {"PASV", "(returns address/port)", command_pasv, STATE_AUTHENTICATED, 0},
    {"EPSV", "(returns address/post)", command_epsv, STATE_AUTHENTICATED, 1},
    {"ALLO", "<sp> size", command_allo, STATE_AUTHENTICATED, 1},
    {"STOR", "<sp> pathname", command_stor, STATE_AUTHENTICATED, 0},
    {"APPE", "<sp> pathname", command_appe, STATE_AUTHENTICATED, 1},
    {"RETR", "<sp> pathname", command_retr, STATE_AUTHENTICATED, 0},
    {"LIST", "[<sp> pathname]", command_list, STATE_AUTHENTICATED, 0},
    {"NLST", "[<sp> pathname]", command_nlst, STATE_AUTHENTICATED, 0},
    {"SYST", "(returns system type)", command_syst, STATE_CONNECTED, 0},
    {"MDTM", "<sp> pathname", command_mdtm, STATE_AUTHENTICATED, 1},
    {"XCWD", "<sp> pathname", command_cwd, STATE_AUTHENTICATED, 1},
    {"CWD", "<sp> pathname", command_cwd, STATE_AUTHENTICATED, 0},
    {"XCUP", "(up one directory)", command_cdup, STATE_AUTHENTICATED, 1},
    {"CDUP", "(up one directory)", command_cdup, STATE_AUTHENTICATED, 0},
    {"DELE", "<sp> pathname", command_dele, STATE_AUTHENTICATED, 0},
    {"XMKD", "<sp> pathname", command_mkd, STATE_AUTHENTICATED, 1},
    {"MKD", "<sp> pathname", command_mkd, STATE_AUTHENTICATED, 0},
    {"XRMD", "<sp> pathname", command_rmd, STATE_AUTHENTICATED, 1},
    {"RMD", "<sp> pathname", command_rmd, STATE_AUTHENTICATED, 0},
    {"NOOP", "(no operation)", command_noop, STATE_AUTHENTICATED, 0},
        {"OPTS", "<sp> string <sp> val", command_opts, STATE_AUTHENTICATED, 0},
    {"RNFR", "<sp> pathname", command_rnfr, STATE_AUTHENTICATED, 0},
    {"RNTO", "<sp> pathname", command_rnto, STATE_RENAME, 0},
    {"REST", "<sp> byte-count", command_rest, STATE_AUTHENTICATED, 1},
    {"SIZE", "<sp> pathname", command_size, STATE_AUTHENTICATED, 1},
    {"QUIT", "(close control connection)", command_quit, STATE_CONNECTED, 0},
    {"HELP", "[<sp> command]", command_help, STATE_AUTHENTICATED, 0},
    {"STAT", "<sp> pathname", command_stat, STATE_AUTHENTICATED, 0},
    {"SITE", "<sp> string", command_site, STATE_AUTHENTICATED, 0},
    {"FEAT", "(returns list of extensions)", command_feat, STATE_AUTHENTICATED, 1},
/*    {"AUTH", "<sp> authtype", command_auth, STATE_CONNECTED, 0},
    {"ADMIN_LOGIN", "(admin)", command_adminlogin, STATE_CONNECTED, 0},*/
      {"MGET", "<sp> pathname", command_mget, STATE_AUTHENTICATED, 0},
      {"MPUT", "<sp> pathname", command_mput, STATE_AUTHENTICATED, 0},
    {NULL, NULL, NULL, 0, 0}
};

void command_feat(char *params)
{}

void command_opts(char *params)
{}


void command_help(char *params)
{}

int parsecmd(char *str)
{
    int i;
    char *p, *pp, confstr[64];
    for (i = 0; commands[i].name; i++) {	/* Parse command */
        if (!strncasecmp(str, commands[i].name, strlen(commands[i].name))) {
            sprintf(confstr, "ALLOWCOMMAND_%s", commands[i].name);
            if (!strcasecmp(config_getoption(confstr), "no")) {
                control_printf(SL_FAILURE, "550 The command '%s' is disabled.",
                        commands[i].name);
                return 1;
            }
            cutto(str, strlen(commands[i].name));
            while ((*p) && ((*p == ' ') || (*p == '\t')))
                p++;
            memmove(str, p, strlen(str) - (p - str) + 1);
            if (state >= commands[i].state_needed) {
                commands[i].function(str);
                return 0;
            } 
        }
    }
    control_printf(SL_FAILURE, "500 Unknown command: \"%s\"", str);}