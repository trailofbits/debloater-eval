#ifndef __BFTPD_DIRLIST_H
#define __BFTPD_DIRLIST_H

struct hidegroup {
    int data;
    struct hidegroup *next;
};

#endif
