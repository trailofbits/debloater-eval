#define PATH_BFTPD_CONF "/etc/bftpd.conf"
