#include <stdlib.h>



void cutto(char *str, int len)
{
    memmove(str, str + len, strlen(str) - len + 1);
}

void mystrncpy(char *dest, char *src, int len)
{
    strncpy(dest, src, len);
    *(dest + len) = 0;
}


/*
Search through str looking for what. Replace any what with
the contents of by. Do not let the string get longer than max_length.
*/
int replace(char *str, char *what, char *by, int max_length)
{
    char *foo, *bar = str;
        int i = 0;
        int str_length, what_length, by_length;
        if (! by) return 0;

        what_length = strlen(what);
        by_length = strlen(by);

        foo = strstr(bar, what);
        /* keep replacing if there is something to replace and it
           will no over-flow
        */
    while ( (foo) && 
                ( (str_length + by_length - what_length) < (max_length - 1) ) ) 
        {
            bar = foo + strlen(by);
            memmove(bar, foo + strlen(what), strlen(foo + strlen(what)) + 1);
        memcpy(foo, by, strlen(by));
            i++;
            foo = strstr(bar, what);
            str_length = strlen(str);
        }
    return i;
}

/* int_from_list(char *list, int n) 
 * returns the n'th integer element from a string like '2,5,12-15,20-23'
 * if n is out of range or *list is out of range, -1 is returned.
 */

int int_from_list(char *list, int n)
{}
