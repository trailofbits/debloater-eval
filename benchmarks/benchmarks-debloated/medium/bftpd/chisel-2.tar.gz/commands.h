#ifndef __BFTPD_COMMANDS_H
#define __BFTPD_COMMANDS_H

enum {
    STATE_CONNECTED, STATE_USER, STATE_AUTHENTICATED, STATE_RENAME, STATE_ADMIN
};

enum {
    TYPE_ASCII, TYPE_BINARY
};

#define USERLEN 30
#define MAXCMD 255

extern int state;
extern char user[USERLEN + 1];
void command_noop(char *);
void command_help(char *);
void command_opts(char *);
void command_feat(char *);

struct command {
  char *name;
  char *syntax;
  void (*function)(char *);
  char state_needed;
  char showinfeat;
};

#endif

