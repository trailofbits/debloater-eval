#include "list.h"



void *bftpd_list_get(struct bftpd_list_element *list, int index)
{}
