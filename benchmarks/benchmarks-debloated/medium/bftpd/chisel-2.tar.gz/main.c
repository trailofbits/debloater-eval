#include <stdio.h>
#include <netdb.h>
#include <unistd.h>
#include "mystring.h"
#include "logging.h"
#include "options.h"

int listensocket, main_sock;
FILE *passwdfile = NULL, *groupfile = NULL, *devnull;

/* Command line parameters */
char *configpath = PATH_BFTPD_CONF;
int daemonmode = 0;

void init_everything()
{
    if (!daemonmode) 
        {
        config_init();}}

int main(int argc, char **argv)
{
    char str[MAX_STRING_LENGTH + 1];
    int i = 1, port;
    int retval;
        socklen_t my_length;

    while (((retval = getopt(argc, argv, "c:hvdDin"))) > -1) {
        switch (retval) {
            case 'h':
                printf(
                    "Usage: %s [-h] [-v] [-i|-d|-D] [-c <filename>|-n]\n"
                    "-h print this help\n"
                                        "-v display version number\n"
                    "-i (default) run from inetd\n"
                    "-d daemon mode: fork() and run in TCP listen mode\n"
                    "-D run in TCP listen mode, but don't pre-fork()\n"
                    "-c read the config file named \"filename\" instead of " PATH_BFTPD_CONF "\n"
                    "-n no config file, use defaults\n", argv[0]);
                return 0;
            case 'D': daemonmode = 2; break;
            case 'c': configpath = strdup(optarg);}
    }
    if (daemonmode) {
        struct sockaddr_in myaddr, new;
        config_init();
        listensocket = socket(AF_INET, SOCK_STREAM, 0);
        if (!((port = strtoul(config_getoption("PORT"), NULL, 10))))
            ;
        myaddr.sin_port = htons(port);
        if (bind(listensocket, (struct sockaddr *) &myaddr, sizeof(myaddr)) < 0) ;
        if (listen(listensocket, 5)) ;
        while ((main_sock = accept(listensocket, (struct sockaddr *) &new, &my_length))) {
            pid_t pid;
			/* If accept() becomes interrupted by SIGCHLD, it will return -1.
			 * So in order not to create a child process when that happens,
			 * we have to check if accept() returned an error.
			 */
            if (main_sock > 0) {
                pid = fork();
                if (!pid) {
                    dup2(main_sock, fileno(stdin));
                    dup2(main_sock, fileno(stderr));
                    break;
                } 
            }
        }
    }
    init_everything();
    control_printf(SL_SUCCESS, "220 %s", str);
        
	/* Read lines from client and execute appropriate commands */
    while (fgets(str, MAXCMD, stdin)) {
                int string_length;
                string_length = strlen(str) - 2;
                str[string_length] = 0;
        parsecmd(str);
    }}

