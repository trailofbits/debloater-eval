
extern char userinfo_set;
char *mygetpwuid(int uid, FILE *file, char *name);