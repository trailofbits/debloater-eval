#ifndef __BFTPD_OPTIONS_H
#define __BFTPD_OPTIONS_H

#include "commands.h"
#include "mypaths.h"

#include <pwd.h>
struct bftpd_option {
  char *name, *value;
  struct bftpd_option *next;
};;
struct global {
    struct bftpd_option *options;
    struct directory *directories;
};
struct user {
    char *name;
    struct bftpd_option *options;
    struct directory *directories;
    struct user *next;
};
char *config_getoption(char *name);

#endif
