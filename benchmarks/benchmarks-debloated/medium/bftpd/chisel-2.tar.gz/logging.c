#include <stdio.h>

#ifdef HAVE_TIME_H
#include <time.h>
#endif#include "options.h"
FILE *logfile = NULL;

/* Status file format:
 * <ID> <Type> <Type2> <String>
 * ID: PID of server process
 * Type: SL_INFO for information, SL_COMMAND for command, SL_REPLY for reply.
 * Type2: If Type = SL_INFO or SL_COMMAND, Type2 is SL_UNDEF. Else,
 * it's SL_SUCCESS for success and SL_FAILURE for error.
 */
void bftpd_statuslog(char type, char type2, char *format, ...)
{}

void bftpd_log(char *format, ...)
{}