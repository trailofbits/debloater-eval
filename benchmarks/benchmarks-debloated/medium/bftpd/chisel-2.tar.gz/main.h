#ifndef __BFTPD_MAIN_H
#define __BFTPD_MAIN_H


#define TRUE 1
#define FALSE 0


extern FILE *passwdfile, *groupfile, *devnull;

/* Command line options */
extern char *configpath;
extern char *post_write_script;

#endif
