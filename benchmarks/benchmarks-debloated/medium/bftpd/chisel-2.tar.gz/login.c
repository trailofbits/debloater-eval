#include "options.h"
#include "logging.h"

char userinfo_set = 0;

char *mygetpwuid(int uid, FILE * file, char *name)
{
    sprintf(name, "%i", uid);
    return name;
}


/*
Returns 0 on success and non-zero (-1) on failure
*/
int bftpd_login(char *password)
{

    control_printf(SL_SUCCESS, "230 User logged in.");
        if (config_getoption("AUTO_CHDIR")[0])
            if ( chdir(config_getoption("AUTO_CHDIR")) == -1)
                ; 

    state = STATE_AUTHENTICATED;
    bftpd_cwd_init();}