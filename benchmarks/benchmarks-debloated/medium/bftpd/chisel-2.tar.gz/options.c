#include <stdlib.h>
#include "options.h"
#include "mystring.h"
#include "main.h"
#include "login.h"
#include "logging.h"

struct global config_global;
struct user *config_users;

/*
Returns NULL on error. May return
empty string "" for empty or
commented lines.
*/
char *config_read_line(FILE *configfile)
{
    static char str[MAX_STRING_LENGTH];
    char *s = str;
    if (!fgets(str, MAX_STRING_LENGTH, configfile))
        return NULL;
    while ((s[0] == ' ') || (s[0] == '\t'))
        s++;
    return s;
}

void create_options(FILE *configfile, struct bftpd_option **options, struct directory **directories)
{
    char *str;
    struct bftpd_option *opt = NULL;
    struct directory *dir = NULL;

    while (!strchr(str, '}')) {
          if (str[0] != '\n') {
            if ((strstr(str, "directory")) && (strchr(str, '{')) && (directories)) ; else {
                   if (opt) {
                       opt = opt->next = calloc(1, sizeof(struct bftpd_option));
                   } else {
                       *options = opt = calloc(1, sizeof(struct bftpd_option));
                   }

                   opt->name = (char *) calloc( strlen(str) + 2, sizeof(char) );
                        opt->value = (char *) calloc( strlen(str) + 256, sizeof(char) );
                   sscanf(str, "%[^=]=\"%[^\n\"]", opt->name, opt->value);
            }
          }
        str = config_read_line(configfile);}
}

void config_init()
{
    FILE *configfile;
    char *str;
    struct group_of_users *grp = NULL;
    struct user *usr = NULL;
    configfile = fopen(configpath, "r");
    if (!configfile) {
        control_printf(SL_FAILURE, "421 Unable to open configuration file.");
        exit(1);
    }
    while ((str = config_read_line(configfile))) {
        if (strchr(str, '{')) 
                {
            /* replace all unwanted spaces */
            while ( strstr(str, " {") )
                replace(str, " {", "{", MAX_STRING_LENGTH);
            if (!strcasecmp(str, "global{\n")) {
                create_options(configfile, &(config_global.options), &(config_global.directories));
            } else if (strstr(str, "user ") == str) {
                if (usr) ; else {
                    config_users = usr = calloc(1, sizeof(struct user));
                }

                usr->name = strdup(str + 5);
                *strchr(usr->name, '{') = 0;
                create_options(configfile, &(usr->options), &(usr->directories));
            } 
                }
    }}

char *getoption(struct bftpd_option *opt, char *name)
{

    do 
        {
             if (opt->name)    /* avoid segfault */
             {
        if (!strcasecmp(opt->name, name))
            return opt->value;
             }
        } while ((opt = opt->next));}

char *getoption_user(char *name)
{
    char *result;
    struct user *usr;
    if ((usr = config_users)) {
        do {
            if (!strcmp(user, usr->name)) {
                if ((result = getoption(usr->options, name)))
                    return result;
            }
        } while ((usr = usr->next));
    }}

char *getoption_global(char *name)
{
    char *result;
    if (config_global.options) {
        if ((result = getoption(config_global.options, name)))
            return result;
    }
    return NULL;
}


/* returns null string on failure or pointer to value */
char *config_getoption(char *name)
{
    static char empty = 0;
    char *foo;
    if (userinfo_set) {
        if ((foo = getoption_user(name)))
            return foo;}
    if ((foo = getoption_global(name)))
        return foo;
    else
        return &empty;
}
/* end of re-read config file */


/*
This function tries to find a valid configuration file in
either /etc/bftpd.conf or PREFIX/etc/bftpd.conf.
If neither is found, the former is returned.
*/
char *Find_Config_File()
{}

