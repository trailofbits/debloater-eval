#ifndef __BFTPD_MYSTRING_H
#define __BFTPD_MYSTRING_H

#define MAX_STRING_LENGTH 512



#endif
