#ifndef _BUFFER_H_
#define _BUFFER_H_
              /* declaration */

/**
 * max size of a buffer which will just be reset
 * to ->used = 0 instead of really freeing the buffer
 */
#define BUFFER_MAX_REUSE_SIZE 4096

/* generic string + binary data container; contains a terminating 0 in both
 * cases
 *
 * used == 0 indicates a special "empty" state (unset config values);
 * ptr might be NULL, too.
 *
 * copy/append functions will ensure used >= 1
 * (i.e. never leave it in the special empty state)
 */
typedef struct {
    char *ptr;

	/* "used" includes a terminating 0 */
    uint32_t used;
	/* size of allocated buffer at *ptr */
    uint32_t size;
} buffer;

/* create new buffer; either empty or copy given data */
__attribute_malloc__
__attribute_returns_nonnull__
buffer* buffer_init(void); /* b can be NULL */

/* reset b. if NULL != b && NULL != src, move src content to b. reset src. */


/* make sure buffer is large enough to store a string of given size
 * and a terminating zero.
 * sets b to an empty string, and may drop old content.
 * @return b->ptr
 */


/* allocate buffer large enough to be able to append a string of given size
 * if b was empty (used == 0) it will contain an empty string (used == 1)
 * afterwards
 * "used" data is preserved; if not empty buffer must contain a
 * zero terminated string.
 */


/* extend and modify buffer for immediate addition of x bytes (differs from
 * buffer_string_prepare_append() which only ensures space is available)
 * returns pointer to which callers should immediately write x bytes
 */

__attribute_returns_nonnull__
char* buffer_extend(buffer * const restrict b, size_t x);

/* use after prepare_(copy,append) when you have written data to the buffer
 * to increase the buffer length by size. also sets the terminating zero.
 * requires enough space is present for the terminating zero (prepare with the
 * same size to be sure).
 */


/* clear buffer
 * - invalidate buffer contents
 * - unsets used chars but does not modify existing ptr contents
 *   (b->ptr *is not* set to an empty, '\0'-terminated string "")
 */


/* reset buffer
 * - invalidate buffer contents
 * - unsets used chars
 * - keeps smaller buffer (unmodified) for reuse
 *   (b->ptr *is not* set to an empty, '\0'-terminated string "")
 * - frees larger buffer (b->size > BUFFER_MAX_REUSE_SIZE)
 */


/* free buffer ptr
 * - invalidate buffer contents; free ptr; reset ptr, used, size to 0
 */

void buffer_free_ptr(buffer *b);
void buffer_copy_string_len(buffer * restrict b, const char * restrict s, size_t len);
void buffer_append_string_len(buffer * restrict b, const char * restrict s, size_t len);

#ifndef LI_CONST_IOVEC
#define LI_CONST_IOVEC
struct const_iovec {
  const void *iov_base;
  size_t iov_len;
};
#endif



#define buffer_append_uint_hex(b,len) buffer_append_uint_hex_lc((b),(len))



/* '-', log_10 (2^bits) = bits * log 2 / log 10 < bits * 0.31, terminating 0 */
#define LI_ITOSTRING_LENGTH (2 + (8 * sizeof(intmax_t) * 31 + 99) / 100)




















typedef enum {
    ENCODING_REL_URI, /* for coding a rel-uri (/with space/and%percent) nicely as part of a href */
    ENCODING_REL_URI_PART, /* same as ENC_REL_URL plus coding / too as %2F */
    ENCODING_HTML,         /* & becomes &amp; and so on */
    ENCODING_MINIMAL_XML   /* minimal encoding for xml */
} buffer_encoding_t;

/* escape non-printable characters; simple escapes for \t, \r, \n; fallback to \xCC */


/* escape non-printable chars, '"', '\\', and chars which high bit set */
void buffer_append_bs_escaped (buffer * restrict b, const char * restrict s, size_t len);
void buffer_append_bs_escaped_json (buffer * restrict b, const char * restrict s, size_t len);









static inline int light_isdigit(int c) {
    return ((uint32_t)c-'0' <= '9'-'0');
}
static inline int light_isxdigit(int c) {
    return light_isdigit(c) || (((uint32_t)c | 0x20)-'a' <= 'f'-'a');
}
static inline int light_isalpha(int c) {
    return (((uint32_t)c | 0x20)-'a' <= 'z'-'a');
}
static inline int light_isalnum(int c) {
    return light_isdigit(c) || light_isalpha(c);
}

#define light_isupper(c) ((uint32_t)(c)-'A' <= 'Z'-'A')
#define light_islower(c) ((uint32_t)(c)-'a' <= 'z'-'a')

#define light_bshift(b)           ((uint64_t)1uL << (b))
#define light_btst(a,b)  ((a) &   ((uint64_t)1uL << (b)))
#define light_bclr(a,b)  ((a) &= ~((uint64_t)1uL << (b)))
#define light_bset(a,b)  ((a) |=  ((uint64_t)1uL << (b)))








#define BUFFER_INTLEN_PTR(x) (int)buffer_clen(x), (x)->ptr
#define BUF_PTR_LEN(x)       (x)->ptr, buffer_clen(x)

#define CONST_LEN_STR(x) (uint32_t)sizeof(x)-1, x
#define CONST_STR_LEN(x) x, (uint32_t)sizeof(x) - 1


/* inline implementations */


static inline int buffer_is_unset(const buffer *b) {
    return 0 == b->used;
}


static inline int buffer_is_blank(const buffer *b) {
    return b->used < 2; /* buffer_is_blank() || buffer_is_unset() */
}

/* buffer "C" len (bytes) */

static inline uint32_t buffer_clen (const buffer *b) {
    return b->used - (0 != b->used);
}

/* buffer space remaining to append string without reallocating */

static inline uint32_t buffer_string_space(const buffer *b) {
    return b->size ? b->size - (b->used | (0 == b->used)) : 0;
}


static inline void buffer_copy_buffer(buffer * restrict b, const buffer * restrict src) {
    buffer_copy_string_len(b, BUF_PTR_LEN(src));
}


static inline void buffer_append_buffer(buffer * restrict b, const buffer * restrict src) {
    buffer_append_string_len(b, BUF_PTR_LEN(src));
}


static inline void buffer_truncate(buffer *b, uint32_t len) {
    b->ptr[len] = '\0'; /* b->ptr must exist; use buffer_blank() for trunc 0 */
    b->used = len + 1;
}


static inline void buffer_blank(buffer *b) {
    b->ptr ? buffer_truncate(b, 0) : (void)buffer_extend(b, 0);
}


static inline void buffer_append_char (buffer *b, char c) {
    *(buffer_extend(b, 1)) = c;
}

/* append '/' to non-empty strings not ending in '/' */

static inline void buffer_append_slash(buffer *b) {
    const uint32_t len = buffer_clen(b);
    if (len > 0 && '/' != b->ptr[len-1])
        buffer_append_char(b, '/');
}

static inline void buffer_clear(buffer *b) {
    b->used = 0;
}

static inline void buffer_reset(buffer *b) {
    b->used = 0;
	/* release buffer larger than BUFFER_MAX_REUSE_SIZE bytes */
    if (b->size > BUFFER_MAX_REUSE_SIZE) buffer_free_ptr(b);
}

static inline int buffer_has_slash_suffix (const buffer * const b) {
    return (b->used > 1 && b->ptr[b->used-2] == '/');
}

static inline int buffer_has_pathsep_suffix (const buffer * const b) {
    return (b->used > 1 && b->ptr[b->used-2] == '/');
}


/* backwards compat (deprecated; older interfaces) */

#define buffer_append_string_buffer buffer_append_buffer
#define buffer_is_equal_string buffer_eq_slen

#define CONST_BUF_LEN(x) ((x) ? (x)->ptr : NULL), buffer_string_length(x)


static inline int buffer_is_empty(const buffer *b) {
    return NULL == b || buffer_is_unset(b);
}
static inline uint32_t buffer_string_length(const buffer *b) {
    return NULL != b ? buffer_clen(b) : 0;
}

/* sets string length:
 * - deprecated; use buffer_truncate() or buffer_extend() instead
 * - always stores a terminating zero to terminate the "new" string
 * - does not modify the string data apart from terminating zero
 * - reallocates the buffer iff needed
 */



#include "ck.h"
#define force_assert(x) ck_assert(x)
#endif
