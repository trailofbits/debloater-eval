#ifndef LI_RAND_H_
#define LI_RAND_H_


#endif
