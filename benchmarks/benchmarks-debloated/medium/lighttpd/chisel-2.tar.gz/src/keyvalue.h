#ifndef _KEY_VALUE_H_
#define _KEY_VALUE_H_
   /* declaration */

typedef struct pcre_keyvalue_ctx {
  struct cond_match_t *cache;
  struct burl_parts_t *burl;
  int m;
  /*(internal use)*/
  int n;
  void *ovec;
  const char *subject;
} pcre_keyvalue_ctx;

typedef struct {
    struct pcre_keyvalue *kv;
    uint32_t used;
    int x0;
    int x1;
    int cfgidx;
} pcre_keyvalue_buffer;

#endif
