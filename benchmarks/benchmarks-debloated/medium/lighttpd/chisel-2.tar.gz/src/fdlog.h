#ifndef INCLUDED_FDLOG_H
#define INCLUDED_FDLOG_H
#include "base_decls.h"
#include "buffer.h"

struct fdlog_st {
    enum { FDLOG_FILE, FDLOG_FD, FDLOG_SYSLOG, FDLOG_PIPE } mode;
    int fd;
    buffer b;
    const char *fn;
};

#endif
