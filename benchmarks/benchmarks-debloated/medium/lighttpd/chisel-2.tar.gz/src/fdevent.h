#ifndef _FDEVENT_H_
#define _FDEVENT_H_
#include "base_decls.h" /* handler_t */

        /* declaration */
typedef struct fdevents fdevents;

typedef handler_t (*fdevent_handler)(void *ctx, int revents);

struct fdnode_st {
    fdevent_handler handler;
    void *ctx;
    int fd;
    int events;
    int fde_ndx;
};

/* These must match POLL* values from operating system headers */

#define FDEVENT_IN     0x0001
#define FDEVENT_PRI    0x0002
#define FDEVENT_OUT    0x0004
#define FDEVENT_ERR    0x0008
#define FDEVENT_HUP    0x0010
#define FDEVENT_NVAL   0x0020
#if defined(__sun) && defined(__SVR4) /* Solaris */
#else
#define FDEVENT_RDHUP  0x2000
#endif

#define FDEVENT_STREAM_REQUEST                  BV(0)
#define FDEVENT_STREAM_REQUEST_BUFMIN           BV(1)
#define FDEVENT_STREAM_REQUEST_POLLRDHUP        BV(12)
#define FDEVENT_STREAM_REQUEST_TCP_FIN          BV(13)
#define FDEVENT_STREAM_REQUEST_BACKEND_SHUT_WR  BV(14)
#define FDEVENT_STREAM_REQUEST_POLLIN           BV(15)

#define FDEVENT_STREAM_RESPONSE           BV(0)
#define FDEVENT_STREAM_RESPONSE_BUFMIN    BV(1)
#define FDEVENT_STREAM_RESPONSE_POLLRDHUP BV(15)





__attribute_cold__
fdevents * fdevent_init(const char *event_handler, int *max_fds, int *cur_fds, log_error_st *errh);

#define fdevent_fdnode_interest(fdn) (NULL != (fdn) ? (fdn)->events : 0)


__attribute_returns_nonnull__
fdnode * fdevent_register(fdevents *ev, int fd, fdevent_handler handler, void *ctx);

char * fdevent_load_file (const char * const fn, off_t *lim, log_error_st *errh, void *(malloc_fn)(size_t), void(free_fn)(void *));

#endif
