#ifndef INCLUDED_LI_PLUGINS_H
#define INCLUDED_LI_PLUGINS_H
#include "base_decls.h"


handler_t plugins_call_handle_request_env(request_st *r);
handler_t plugins_call_handle_request_reset(request_st *r);

#endif
