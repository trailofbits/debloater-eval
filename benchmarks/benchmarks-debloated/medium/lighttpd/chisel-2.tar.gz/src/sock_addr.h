#ifndef INCLUDED_SOCK_ADDR_H
#define INCLUDED_SOCK_ADDR_H
#include "sys-socket.h"

#include "base_decls.h"
union sock_addr {
#ifdef HAVE_IPV6
    struct sockaddr_in6 ipv6;
#endif
    struct sockaddr_in ipv4;
#ifdef HAVE_SYS_UN_H
    struct sockaddr_un un;
#endif
    struct sockaddr plain;
};
static inline int sock_addr_get_family (const sock_addr *saddr) {
    return saddr->plain.sa_family;
}

#if 0

#endif


#endif
