#ifndef INCLUDED_NETWORK_WRITE_H
#define INCLUDED_NETWORK_WRITE_H


__attribute_cold__

#endif
