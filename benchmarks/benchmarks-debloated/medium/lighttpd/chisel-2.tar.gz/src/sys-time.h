/*
 * sys-time.h - time.h wrapper for localtime_r() and gmtime_r()
 *
 * Copyright(c) 2015 Glenn Strauss gstrauss()gluelogic.com  All rights reserved
 * License: BSD 3-clause (same as lighttpd)
 */
#ifndef LI_SYS_TIME_H
#define LI_SYS_TIME_H
#ifdef HAVE_SYS_TIME_H
#include <sys/time.h>/* gettimeofday() */
#endif
#include <time.h>    /* time() localtime_r() gmtime_r() strftime() */

/*(provide rudimentary localtime_r() and gmtime_r() for platforms lacking)
 *(Note that 'result' preprocessor arg is repeated, so callers should avoid
 * side-effects.  Also note that there is still a race condition before the
 * result of localtime()/gmtime() is copied.  In any case, this exists here
 * so that the rest of the code can use localtime_r() and gmtime_r() syntax.
 * Platforms requiring thread-safety and lacking localtime_r() or gmtime_r()
 * could turn these into subroutines which take a local mutex to protect the
 * calls to localtime() or gmtime()) */
#ifndef HAVE_LOCALTIME_R
#define localtime_r(timep,result) ((*(result) = *(localtime(timep))), (result))
#endif
#ifndef HAVE_GMTIME_R
#define gmtime_r(timep,result)    ((*(result) = *(gmtime(timep))),    (result))
#endif

#ifndef HAVE_TIMEGM
#ifdef _WIN32#else
#endif
#endif


/* non-standard functions created for lighttpd for Y2038 problem
 * reference: https://en.wikipedia.org/wiki/Year_2038_problem
 *
 * lighttpd does not expect to deal with dates earlier than 1970,
 * and can therefore treat dates earlier than 1970 as having overflowed
 * 32-bit signed time_t, signifying dates after Tue, 19 Jan 2038 03:14:07 GMT
 *
 * 1954, 1982, 2010, 2038 begin on Thu and are two years offset from leap year.
 * Attempt to adjust a timestamp > INT32_MAX back to a similar year, starting on
 * same weekday, and being same distance from next leap year; use gmtime_r()
 * or localtime_r(); and then adjust tm.tm_year back to the year of the original
 * timestamp.  (Note that the calculations here are valid for the specific range
 * of input timestamps mapped to 1970 and 2099.  The year 2000 was a leap year,
 * so crossing 2000 *does not* require special-casing here, but the year 2100
 * *is not* a leap year in the Gregorian calendar, so this code is not valid
 * after 28 Feb 2100.  Since the max validity of these kludges could only be
 * until 7 Feb 2106, this code has chosen not to special-case 2100-2106 and
 * produces incorrect results after 28 Feb 2100.)
 */
#if HAS_TIME_BITS64

#define gmtime64_r(timep,result)    gmtime_r((timep),(result))
#define localtime64_r(timep,result) localtime_r((timep),(result))

#else

#endif /* !HAS_TIME_BITS64 */


#endif
