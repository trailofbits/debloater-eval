#ifndef _RESPONSE_H_
#define _RESPONSE_H_
#include "base_decls.h"
#include "array.h"



enum {
  BACKEND_PROXY = 0
,BACKEND_CGI
,BACKEND_FASTCGI
,BACKEND_SCGI
,BACKEND_AJP13
};

typedef struct http_response_opts_t {
  uint32_t max_per_read;
  int fdfmt;
  int backend;
  int authorizer; /* bool *//*(maybe overloaded w/ response streaming flags)*/
  uint8_t simple_accum; /* bool */
  uint8_t local_redir; /* 0,1,2 */
  uint8_t xsendfile_allow; /* bool */
  const array *xsendfile_docroot;
  void *pdata;
  handler_t(*parse)(request_st *, struct http_response_opts_t *, buffer *, size_t);
  handler_t(*headers)(request_st *, struct http_response_opts_t *);
} http_response_opts;

typedef int (*http_response_send_1xx_cb)(request_st *r, connection *con);

#endif
