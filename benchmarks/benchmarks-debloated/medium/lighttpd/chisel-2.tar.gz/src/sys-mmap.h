#ifndef LI_SYS_MMAP_H
#define LI_SYS_MMAP_H
#if defined(HAVE_SYS_MMAN_H)

#include <sys/mman.h>

#elif defined(_WIN32)
#ifndef MAP_FAILED
#define MAP_FAILED ((void *)-1)
#endif
#ifndef MAP_PRIVATE
#define MAP_PRIVATE 0
#endif
#ifndef MAP_SHARED
#define MAP_SHARED 0
#endif
#ifndef PROT_READ
#define PROT_READ PAGE_READONLY
#endif

#else# define mmap(a, b, c, d, e, f) (-1)
#endif /* HAVE_SYS_MMAN_H */

/* NetBSD 1.3.x needs it; also make it available if mmap() is not present */
#if !defined(MAP_FAILED)
#endif

#endif
