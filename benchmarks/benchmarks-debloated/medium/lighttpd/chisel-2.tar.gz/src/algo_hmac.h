/* algo_hmac - hash-based message authentication code (HMAC) wrapper
 *
 * Copyright(c) 2021 Glenn Strauss gstrauss()gluelogic.com  All rights reserved
 * License: BSD 3-clause (same as lighttpd)
 */
#ifndef INCLUDED_ALGO_HMAC_H
#define INCLUDED_ALGO_HMAC_H



#endif /* INCLUDED_ALGO_HMAC_H */
