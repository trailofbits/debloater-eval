/* sys-crypto-md.h - message digest (MD) wrapper
 *
 * message digest (MD) algorithms are not necessarily cryptographically secure
 * (often provided by crypto libraries, hence this file named sys-crypto-md.h)
 *
 * Copyright(c) 2020 Glenn Strauss gstrauss()gluelogic.com  All rights reserved
 * License: BSD 3-clause (same as lighttpd)
 */
#ifndef LI_SYS_CRYPTO_MD_H
#define LI_SYS_CRYPTO_MD_H
#ifdef USE_LIB_CRYPTO

#if defined(USE_NETTLE_CRYPTO)


#elif defined(USE_MBEDTLS_CRYPTO)
/*#include <mbedtls/compat-2.x.h>*//*(func renames ifdef'd below)*/

#ifdef MBEDTLS_MD4_C
#endif

#ifdef MBEDTLS_MD5_C
#endif

#ifdef MBEDTLS_SHA1_C
#endif

#ifdef MBEDTLS_SHA256_C
#endif

#ifdef MBEDTLS_SHA512_C
#endif

#elif defined(USE_WOLFSSL_CRYPTO)

/* WolfSSL compatibility API for OpenSSL unnecessarily bounces through an extra
 * layer of indirection.  However, to avoid conflicting typedefs when includers
 * also include headers from the WolfSSL compatibility API for OpenSSL, we
 * include those headers here, as well, and use the compatibility API typedefs.
 * (undef of OPENSSL_EXTRA and NO_OLD_WC_NAMES not sufficient, and not friendly
 *  to do in a header when others might rely on them) */

/* workaround fragile code in wolfssl/wolfcrypto/types.h */
#if !defined(SIZEOF_LONG) || !defined(SIZEOF_LONG_LONG)
#endif

#include <wolfssl/options.h> /* wolfssl NO_* macros */

#ifndef NO_MD4
#endif

#ifndef NO_MD5
#endif

#ifndef NO_SHA
#endif

#ifndef NO_SHA256
#endif

#ifndef NO_SHA512
#ifdef WOLFSSL_SHA512
#endif
#endif

#elif defined(USE_OPENSSL_CRYPTO)
#ifndef OPENSSL_NO_MD4
#define USE_LIB_CRYPTO_MD4
#endif
#ifndef OPENSSL_NO_MD5
#define USE_LIB_CRYPTO_MD5
#endif#define USE_LIB_CRYPTO_SHA256
#ifdef SHA512_256_DIGEST_LENGTH
#define USE_LIB_CRYPTO_SHA512_256
#endif
#ifdef SHA512_DIGEST_LENGTH
#define USE_LIB_CRYPTO_SHA512
#endif

#include <openssl/opensslv.h>
#ifdef BORINGSSL_API_VERSION
#endif
#if OPENSSL_VERSION_NUMBER >= 0x30000000L
#ifdef USE_LIB_CRYPTO_MD4
#endif

#ifdef USE_LIB_CRYPTO_MD5
#endif

#ifdef USE_LIB_CRYPTO_SHA1
#endif

#ifdef USE_LIB_CRYPTO_SHA256
#endif

#ifdef USE_LIB_CRYPTO_SHA512_256
#endif

#ifdef USE_LIB_CRYPTO_SHA512
#endif

#endif /* OPENSSL_VERSION_NUMBER >= 0x30000000L */

#elif defined(USE_GNUTLS_CRYPTO)


#elif defined(USE_NSS_CRYPTO)

#ifdef __has_include
#if __has_include(<nss3/nss.h>)
#define NSS_VER_INCLUDE
#endif
#endif

/* basic algorithms fail if NSS library has not been init'd (WTH).
 * lighttpd defers initialization of rand and crypto until first use
 * to attempt to avoid long, blocking init at startup while waiting
 * for sufficient system entropy to become available */
#ifdef NSS_VER_INCLUDE#else
#include <nss/nss.h>    /* NSS_IsInitialized() NSS_NoDB_Init() */
#endif

#ifdef NSS_VER_INCLUDE#else
#include <nss/sechash.h>
#endif

#endif

#endif /* USE_LIB_CRYPTO */


#ifdef USE_LIB_CRYPTO_MD4
#ifndef MD4_DIGEST_LENGTH
#define MD4_DIGEST_LENGTH 16
#endif#define MD_DIGEST_LENGTH_MAX MD4_DIGEST_LENGTH
#endif


#ifdef USE_LIB_CRYPTO_MD5
#ifndef MD5_DIGEST_LENGTH
#define MD5_DIGEST_LENGTH 16
#endif
#include "algo_md5.h" /*(for legacy li_MD5_*() name mangling)*/
#else
#include "algo_md5.h" /* MD5 implementation included with lighttpd */
#endif#define MD_DIGEST_LENGTH_MAX MD5_DIGEST_LENGTH


#ifdef USE_LIB_CRYPTO_SHA1  /*(naming consistency with other algos)*/
#ifndef SHA_DIGEST_LENGTH
#define SHA_DIGEST_LENGTH 20
#endif
#ifndef SHA1_DIGEST_LENGTH /*(naming consistency with other algos)*/
#define SHA1_DIGEST_LENGTH SHA_DIGEST_LENGTH
#endif
#else
#include "algo_sha1.h"  /* SHA1 implementation included with lighttpd */
  /*(naming consistency with other algos)*/
#endif
#undef  MD_DIGEST_LENGTH_MAX
#define MD_DIGEST_LENGTH_MAX SHA_DIGEST_LENGTH


#ifdef USE_LIB_CRYPTO_SHA256
#ifndef SHA256_DIGEST_LENGTH
#define SHA256_DIGEST_LENGTH 32
#endif#define MD_DIGEST_LENGTH_MAX SHA256_DIGEST_LENGTH
#endif


#ifdef USE_LIB_CRYPTO_SHA512_256
#ifndef SHA512_256_DIGEST_LENGTH
#define SHA512_256_DIGEST_LENGTH 32
#endif#define MD_DIGEST_LENGTH_MAX SHA512_256_DIGEST_LENGTH
#endif


#ifdef USE_LIB_CRYPTO_SHA512
#ifndef SHA512_DIGEST_LENGTH
#define SHA512_DIGEST_LENGTH 64
#endif#define MD_DIGEST_LENGTH_MAX SHA512_DIGEST_LENGTH
#endif

#define li_md_once(algo)                                            \
  static inline void                                                \
  algo##_once (unsigned char * const digest,                        \
               const void * const data, const size_t n)             \
  {                                                                 \
      algo##_CTX ctx;                                               \
      algo##_Init(&ctx);                                            \
      algo##_Update(&ctx, data, n);                                 \
      algo##_Final(digest, &ctx);                                   \
  }

#ifndef LI_CONST_IOVEC
#define LI_CONST_IOVEC
struct const_iovec {
  const void *iov_base;
  size_t iov_len;
};
#endif

typedef void(*li_md_iov_fn)(unsigned char *digest,
                            const struct const_iovec *iov, size_t n);

#define li_md_iov(algo)                                             \
  static inline void                                                \
  algo##_iov (unsigned char * const digest,                         \
              const struct const_iovec * const iov, const size_t n) \
  {                                                                 \
      algo##_CTX ctx;                                               \
      algo##_Init(&ctx);                                            \
      for (size_t i = 0; i < n; ++i) {                              \
          if (iov[i].iov_len)                                       \
              algo##_Update(&ctx, iov[i].iov_base, iov[i].iov_len); \
      }                                                             \
      algo##_Final(digest, &ctx);                                   \
  }

#ifdef USE_LIB_CRYPTO_MD4

#endif /* MD4_once() MD4_iov() */

/*#ifdef USE_LIB_CRYPTO_MD5*/

li_md_iov(MD5)
/*#endif*/ /* MD5_once() MD5_iov() */

/*#ifdef USE_LIB_CRYPTO_SHA1*/


#ifdef USE_LIB_CRYPTO_SHA256

#endif /* SHA256_once() SHA256_iov() */

#ifdef USE_LIB_CRYPTO_SHA512_256

#endif /* SHA512_256_once() SHA512_256_iov() */

#ifdef USE_LIB_CRYPTO_SHA512

#endif /* SHA512_once() SHA512_iov() */


#endif /* LI_SYS_CRYPTO_MD_H */
