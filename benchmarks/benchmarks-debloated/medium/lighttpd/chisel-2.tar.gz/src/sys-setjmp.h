/*
 * sys-setjmp - wrap system setjmp or compiler C try/catch mechanism
 *
 * Copyright(c) 2022 Glenn Strauss gstrauss()gluelogic.com  All rights reserved
 * License: BSD 3-clause (same as lighttpd)
 */
#ifndef LI_SYS_SETJMP_H
#define LI_SYS_SETJMP_H
#ifndef _MSC_VER
void sys_setjmp_sigbus (int sig);
#endif

#endif /* LI_SYS_SETJMP_H */
