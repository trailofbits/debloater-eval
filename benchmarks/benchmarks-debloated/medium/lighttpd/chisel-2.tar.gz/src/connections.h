#ifndef _CONNECTIONS_H_
#define _CONNECTIONS_H_


int connection_send_1xx (request_st *r, connection *con);

connection * connection_accepted(server *srv, const struct server_socket *srv_socket, sock_addr *cnt_addr, int cnt);

void connection_state_machine(connection *con);

#endif
