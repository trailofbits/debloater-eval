#ifndef _FILE_CACHE_H_
#define _FILE_CACHE_H_
#include <sys/stat.h>
#include "array.h"

typedef struct stat stat_cache_st;

typedef struct stat_cache_entry {
    buffer name;
    unix_time64_t stat_ts;
    int fd;
    int refcnt;
  #if defined(HAVE_FAM_H) || defined(HAVE_SYS_INOTIFY_H) || defined(HAVE_SYS_EVENT_H)
    void *fam_dir;
  #endif
    buffer etag;
    buffer content_type;
    struct stat st;
} stat_cache_entry;

void stat_cache_entry_refchg(void *data, int mod);

#if defined(HAVE_XATTR) || defined(HAVE_EXTATTR)
#else
const buffer * stat_cache_content_type_get_by_ext(stat_cache_entry *sce, const array *mimetypes);
#define stat_cache_content_type_get(con, r) stat_cache_content_type_get_by_ext((sce), (r)->conf.mimetypes)
#endif
const buffer * stat_cache_etag_get(stat_cache_entry *sce, int flags);
void stat_cache_update_entry(const char *name, uint32_t len, const struct stat *st, const buffer *etagb);
void stat_cache_invalidate_entry(const char *name, uint32_t len);
stat_cache_entry * stat_cache_get_entry(const buffer *name);
stat_cache_entry * stat_cache_get_entry_open(const buffer *name, int symlinks);
#endif
