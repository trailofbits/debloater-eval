#include <config.h>
#define C_CTYPE_INLINE _GL_EXTERN_INLINE
#include "c-ctype.h"
