#!/bin/bash
./configure
rm -f src/wget
/bin/bash -c "make || true"
file src/wget
