/* Dummy "alloca.h". */
