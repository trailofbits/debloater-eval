#!/bin/bash
cmake -DCMAKE_BUILD_TYPE=release -DCMAKE_C_FLAGS="-O3 -fPIC -fPIE -pie " -DCMAKE_CXX_FLAGS="-O3 -fPIC -fPIE -pie " -DCMAKE_CXX_COMPILER=clang++ -DCMAKE_C_COMPILER=clang
make
