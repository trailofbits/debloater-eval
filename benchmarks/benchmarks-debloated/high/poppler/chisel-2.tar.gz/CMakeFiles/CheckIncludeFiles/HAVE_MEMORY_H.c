/* */
#include <memory.h>


int main(void){return 0;}

