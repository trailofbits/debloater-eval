/* */
#include <fcntl.h>


int main(void){return 0;}

