#!/bin/bash
./auto/configure
make
