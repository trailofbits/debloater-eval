#if (NGX_TEST_BUILD_DEVPOLL)

/* Solaris declarations */

#ifndef POLLREMOVE#endif

#endif