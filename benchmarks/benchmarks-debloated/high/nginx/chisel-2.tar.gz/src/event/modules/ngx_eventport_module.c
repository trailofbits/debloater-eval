#if (NGX_TEST_BUILD_EVENTPORT)
#ifndef CLOCK_REALTIME
#elif (NGX_DARWIN)

#endif#ifndef ETIME#endif

#if (__FreeBSD__ && __FreeBSD_version < 700005) || (NGX_DARWIN)


#endif

#endif