

#if (NGX_HAVE_INET6)


#endif

#if (NGX_HAVE_UNIX_DOMAIN)


#endif
#if (NGX_HAVE_INET6)

#endif
#if (NGX_HAVE_UNIX_DOMAIN)

#endif


#if (NGX_HAVE_INET6)


#endif


#if (NGX_HAVE_UNIX_DOMAIN)


#endif