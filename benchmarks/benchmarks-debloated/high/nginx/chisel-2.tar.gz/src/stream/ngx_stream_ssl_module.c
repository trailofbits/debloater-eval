
#ifdef SSL_CTRL_SET_TLSEXT_HOSTNAME
#endif
#ifdef TLSEXT_TYPE_application_layer_protocol_negotiation
#endif
#ifdef SSL_R_CERT_CB_ERROR
#endif


#ifdef SSL_CTRL_SET_TLSEXT_HOSTNAME

#endif


#ifdef TLSEXT_TYPE_application_layer_protocol_negotiation

#endif


#ifdef SSL_R_CERT_CB_ERROR

#endif