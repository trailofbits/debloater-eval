#if (NGX_LINUX)


#elif (NGX_FREEBSD) && (__FreeBSD_version >= 900031)


#elif (NGX_DARWIN)


/*
 * 2) Kernel thread mach_port_t returned by pthread_mach_thread_np().
 *    It is a number in range 100-100,000.
 *
 * return pthread_mach_thread_np(pthread_self());
 */

#else

#endif
