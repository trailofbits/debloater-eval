
/*
 * Copyright (C) Igor Sysoev
 * Copyright (C) Nginx, Inc.
 */


#ifndef _NGX_USER_H_INCLUDED_
#define _NGX_USER_H_INCLUDED_


typedef uid_t  ngx_uid_t;
typedef gid_t  ngx_gid_t;


#endif /* _NGX_USER_H_INCLUDED_ */
