
/*
 * Copyright (C) Igor Sysoev
 * Copyright (C) Nginx, Inc.
 */


#ifndef _NGX_HTTP_PERL_MODULE_H_INCLUDED_


#endif /* _NGX_HTTP_PERL_MODULE_H_INCLUDED_ */
